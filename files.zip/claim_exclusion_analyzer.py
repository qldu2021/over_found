"""
Claim Exclusion Analyzer
Analyzes why a specific claim (CLCL_ID) was excluded from the final output table
using OpenAI GPT-4 to interpret complex SQL deletion logic.
"""

import snowflake.connector
from openai import OpenAI
import os
from typing import Dict, List, Tuple
import json

class ClaimExclusionAnalyzer:
    def __init__(self, snowflake_config: Dict, openai_api_key: str):
        """
        Initialize the analyzer with Snowflake and OpenAI credentials.
        
        Args:
            snowflake_config: Dict with keys: user, password, account, warehouse, database, schema
            openai_api_key: OpenAI API key
        """
        self.sf_conn = snowflake.connector.connect(**snowflake_config)
        self.client = OpenAI(api_key=openai_api_key)
        
    def get_claim_data(self, clcl_id: str) -> Dict:
        """Fetch claim data from Snowflake tables."""
        cursor = self.sf_conn.cursor()
        
        query = f"""
        SELECT 
            clcl.CLCL_ID,
            clcl.GRGR_CK,
            clcl.SBSB_CK,
            clcl.CLCL_CUR_STS,
            clcl.CLCL_PAID_DT,
            clcl.CLCL_RECD_DT,
            clcl.CSCS_ID,
            clcl.CLCL_TOT_PAYABLE,
            clcl.CLCL_EOB_EXCD_ID,
            cdml.CDML_SEQ_NO,
            cdml.CDML_DISALL_EXCD,
            cdml.CDML_FROM_DT,
            cdml.CDML_TO_DT,
            cdml.CDML_PR_PYMT_AMT,
            cdml.IPCD_ID,
            cdml.RCRC_ID,
            clhp.CLHP_FAC_TYPE,
            clhp.CLHP_BILL_CLASS,
            m.MARKET_NAME,
            pdpd.LOBD_ID
        FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLCL_CLAIM_CMPCT_ACTV clcl
        LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV cdml 
            ON clcl.CLCL_ID = cdml.CLCL_ID
        LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLHP_HOSP_CMPCT_ACTV clhp 
            ON clcl.CLCL_ID = clhp.CLCL_ID
        LEFT JOIN markets m 
            ON clcl.GRGR_CK = m.GRGR_CK
        LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_PDPD_PRODUCT_CMPCT_ACTV pdpd 
            ON clcl.PDPD_ID = pdpd.PDPD_ID
        WHERE clcl.CLCL_ID = '{clcl_id}'
        """
        
        cursor.execute(query)
        columns = [col[0] for col in cursor.description]
        results = cursor.fetchall()
        
        if not results:
            return None
            
        # Convert to list of dicts (one per line item)
        claim_data = []
        for row in results:
            claim_data.append(dict(zip(columns, row)))
        
        cursor.close()
        return claim_data
    
    def extract_deletion_rules(self, sql_file_path: str) -> List[Dict]:
        """
        Extract all DELETE statements from the SQL file and structure them.
        """
        with open(sql_file_path, 'r') as f:
            sql_content = f.read()
        
        # This is a simplified extraction - you might need more sophisticated parsing
        deletion_rules = []
        
        # Split by DELETE statements
        delete_blocks = sql_content.split('delete from report_output')
        
        for i, block in enumerate(delete_blocks[1:], 1):  # Skip first split (before first DELETE)
            # Extract the WHERE clause (up to the next DELETE or end of relevant section)
            where_end = block.find(';')
            if where_end == -1:
                where_end = len(block)
            
            where_clause = block[:where_end].strip()
            
            # Extract the section comment if exists
            lines_before = delete_blocks[i-1].split('\n')
            comment = ""
            for line in reversed(lines_before[-5:]):  # Check last 5 lines before DELETE
                if '--' in line:
                    comment = line.split('--')[1].strip()
                    break
            
            deletion_rules.append({
                'rule_number': i,
                'comment': comment,
                'where_clause': where_clause,
                'full_statement': f"delete from report_output {where_clause}"
            })
        
        return deletion_rules
    
    def analyze_exclusion(self, clcl_id: str, sql_file_path: str) -> str:
        """
        Main method to analyze why a claim was excluded.
        """
        # Get claim data
        claim_data = self.get_claim_data(clcl_id)
        
        if not claim_data:
            return f"Claim {clcl_id} not found in the database."
        
        # Extract deletion rules from SQL
        deletion_rules = self.extract_deletion_rules(sql_file_path)
        
        # Prepare the prompt for GPT
        prompt = f"""
You are a SQL analyst expert. I need you to analyze why a specific healthcare claim was excluded from a final output table.

**Claim ID:** {clcl_id}

**Claim Data:**
```json
{json.dumps(claim_data, indent=2, default=str)}
```

**SQL Deletion Rules Applied:**
The following DELETE statements are executed in sequence on the report_output table:

"""
        
        for rule in deletion_rules:
            prompt += f"""
---
**Rule {rule['rule_number']}:** {rule['comment']}
```sql
{rule['full_statement']}
```
"""
        
        prompt += """

**Your Task:**
1. Analyze each deletion rule carefully
2. Determine which rule(s) would cause this claim to be deleted
3. Explain in clear, business-friendly language WHY the claim was excluded
4. Provide specific data values that triggered the exclusion
5. If multiple rules apply, list them all

**Format your response as:**
- **Exclusion Reason:** [Brief summary]
- **Specific Rule(s):** [Rule number and description]
- **Data Points:** [The specific values that caused exclusion]
- **Business Explanation:** [Plain English explanation]

If the claim was NOT excluded, explain why it would remain in the final output.
"""
        
        # Call OpenAI API
        response = self.client.chat.completions.create(
            model="gpt-4-turbo-preview",
            messages=[
                {"role": "system", "content": "You are an expert SQL analyst specializing in healthcare claims processing and data analysis."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,
            max_tokens=2000
        )
        
        return response.choices[0].message.content
    
    def check_specific_rules(self, clcl_id: str) -> Dict[str, bool]:
        """
        Check specific common exclusion rules programmatically.
        """
        cursor = self.sf_conn.cursor()
        
        checks = {}
        
        # Example checks based on the SQL
        
        # Check 1: Market exclusion (GRGR_CK in excluded list)
        cursor.execute(f"""
            SELECT GRGR_CK FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLCL_CLAIM_CMPCT_ACTV
            WHERE CLCL_ID = '{clcl_id}'
        """)
        result = cursor.fetchone()
        if result:
            grgr_ck = result[0]
            checks['excluded_market'] = grgr_ck in (10, 12, 15, 20, 22)
        
        # Check 2: Total payable threshold
        cursor.execute(f"""
            SELECT GRGR_CK, CLCL_TOT_PAYABLE 
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLCL_CLAIM_CMPCT_ACTV
            WHERE CLCL_ID = '{clcl_id}'
        """)
        result = cursor.fetchone()
        if result:
            grgr_ck, tot_payable = result
            if grgr_ck in (3, 34, 13, 31):
                checks['below_payable_threshold'] = tot_payable < 10
            else:
                checks['below_payable_threshold'] = tot_payable < 25
        
        # Check 3: Excluded disallowance codes
        cursor.execute(f"""
            SELECT CDML_DISALL_EXCD 
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV
            WHERE CLCL_ID = '{clcl_id}'
        """)
        excluded_codes = ['FA5', 'FA7', 'A01', 'A02', 'A03', 'A04', 'A05', 'A06', 
                         'A07', 'A08', 'A09', 'A10', 'A11', 'A12', 'A13', 'A14']
        results = cursor.fetchall()
        checks['has_excluded_disallow_code'] = any(row[0] in excluded_codes for row in results)
        
        # Check 4: TN specific exclusion (CHM0021b)
        cursor.execute(f"""
            SELECT clcl.GRGR_CK, clcl.CSCS_ID, cdml.CDML_FROM_DT, clhp.CLHP_FAC_TYPE, clhp.CLHP_BILL_CLASS
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLCL_CLAIM_CMPCT_ACTV clcl
            JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV cdml ON clcl.CLCL_ID = cdml.CLCL_ID
            LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLHP_HOSP_CMPCT_ACTV clhp ON clcl.CLCL_ID = clhp.CLCL_ID
            WHERE clcl.CLCL_ID = '{clcl_id}'
        """)
        result = cursor.fetchone()
        if result:
            grgr_ck, cscs_id, cdml_from_dt, fac_type, bill_class = result
            tn_plans = ['PL10','PL11','PL12','PL95','PL96','PL97','CD04','CD05','CD06','CD07','CD08','CD09']
            bill_types = ['066', '089']
            checks['tn_specific_exclusion'] = (
                grgr_ck == 13 and 
                cscs_id in tn_plans and 
                f"{fac_type or ''}{bill_class or ''}" in bill_types and
                cdml_from_dt and cdml_from_dt > '2024-06-30'
            )
        
        cursor.close()
        return checks
    
    def close(self):
        """Close database connection."""
        self.sf_conn.close()


# Example usage
if __name__ == "__main__":
    # Configuration
    snowflake_config = {
        'user': os.getenv('SNOWFLAKE_USER'),
        'password': os.getenv('SNOWFLAKE_PASSWORD'),
        'account': os.getenv('SNOWFLAKE_ACCOUNT'),
        'warehouse': os.getenv('SNOWFLAKE_WAREHOUSE'),
        'database': 'P01_EDL',
        'schema': 'EDL_RAWZ_CMPCT_ALLPHI'
    }
    
    openai_api_key = os.getenv('OPENAI_API_KEY')
    
    # Initialize analyzer
    analyzer = ClaimExclusionAnalyzer(snowflake_config, openai_api_key)
    
    # Analyze a specific claim
    clcl_id = "CLM123456789"  # Replace with actual claim ID
    
    print("Checking specific rules programmatically...")
    rule_checks = analyzer.check_specific_rules(clcl_id)
    print("\nRule Check Results:")
    for rule, is_excluded in rule_checks.items():
        print(f"  {rule}: {'EXCLUDED' if is_excluded else 'PASSED'}")
    
    print("\n" + "="*80)
    print("Analyzing with GPT-4...")
    print("="*80 + "\n")
    
    # Get AI analysis
    sql_file_path = "path/to/your/sql_file.sql"  # Path to your SQL file
    analysis = analyzer.analyze_exclusion(clcl_id, sql_file_path)
    
    print(analysis)
    
    # Close connection
    analyzer.close()
