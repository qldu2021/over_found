# Claim Exclusion Analyzer

Analyzes why specific healthcare claims are excluded from the final output table using both programmatic rule checks and OpenAI GPT-4 for comprehensive analysis.

## Features

- **Automated Rule Checking**: Programmatically evaluates claims against 14+ exclusion rules
- **GPT-4 Analysis**: Provides detailed, business-friendly explanations
- **Comprehensive Coverage**: Checks all major exclusion categories:
  - Market exclusions
  - Payment thresholds
  - Disallowance codes
  - Date-based filters
  - Provider type restrictions
  - Override codes
  - And more...

## Prerequisites

```bash
pip install snowflake-connector-python openai python-dotenv
```

## Environment Setup

Create a `.env` file with your credentials:

```env
# Snowflake Configuration
SNOWFLAKE_USER=your_username
SNOWFLAKE_PASSWORD=your_password
SNOWFLAKE_ACCOUNT=your_account
SNOWFLAKE_WAREHOUSE=your_warehouse

# OpenAI Configuration
OPENAI_API_KEY=your_openai_api_key
```

## Quick Start

### Basic Usage

```python
from enhanced_claim_analyzer import EnhancedClaimAnalyzer
import os
from dotenv import load_dotenv

load_dotenv()

# Configuration
snowflake_config = {
    'user': os.getenv('SNOWFLAKE_USER'),
    'password': os.getenv('SNOWFLAKE_PASSWORD'),
    'account': os.getenv('SNOWFLAKE_ACCOUNT'),
    'warehouse': os.getenv('SNOWFLAKE_WAREHOUSE'),
    'database': 'P01_EDL',
    'schema': 'EDL_RAWZ_CMPCT_ALLPHI'
}

# Initialize analyzer
analyzer = EnhancedClaimAnalyzer(
    snowflake_config, 
    os.getenv('OPENAI_API_KEY')
)

# Analyze a claim
analysis = analyzer.analyze_claim('CLM123456789')
print(analysis)

# Clean up
analyzer.close()
```

### Command Line Usage

```bash
python enhanced_claim_analyzer.py
```

You'll be prompted to enter:
1. Claim ID (CLCL_ID)
2. Line Sequence Number (optional)

## Exclusion Rules Checked

### RULE_001: Excluded Markets
- **Description**: Markets excluded from analysis
- **Markets**: NM (10), MD-VANT (12), VA (15), VA-VANT (20), Other (22)
- **Reference**: Line ~800 in SQL

### RULE_002: Unrecoverable Disallowance Codes
- **Description**: Claims with appeal-related or plan-approval codes
- **Codes**: FA5, FA7, A01-A58, K01-K25
- **Reference**: exclude_disall_excd table

### RULE_003: HMS/Connolly Line Items
- **Description**: Claim-level HMS and Connolly exclusions
- **Codes**: FA6, FA8
- **Reference**: CLCL_EOB_EXCD_ID check

### RULE_004: Below Payment Threshold
- **Description**: Claims below minimum payment amount
- **Thresholds**: 
  - $10 for markets 3, 34, 13, 31
  - $25 for all other markets
- **Reference**: CHM0005

### RULE_005: TN Plan Specific Exclusion (CHM0021b)
- **Description**: Tennessee market with specific criteria
- **Criteria**:
  - GRGR_CK = 13 (TN market)
  - Plan IDs: PL10, PL11, PL12, PL95, PL96, PL97, CD04-CD09
  - Bill types: 066, 089
  - Service dates after 2024-06-30
- **Example**: This is the rule you asked about!

### RULE_006: Malicious Override Codes
- **Description**: Claims with specific override codes
- **Codes**: J00, J01, J02, JCN, YHK, EAM, G03, G97, FD3, FD4, FD5
- **Tables Checked**: CDML, CDOR, CLOR, ADJ_CLM_RSN
- **Reference**: CH0009C, CHM0003b

### RULE_007: Expired Claims
- **Description**: Claims exceeding market-specific expiration dates
- **Logic**: Complex expiration rules by market and claim type
- **Reference**: CH0006B

### RULE_008: DC Market Date Filter
- **Description**: DC market claims before specific date
- **Criteria**: GRGR_CK = 6 AND CDML_FROM_DT < 2017-01-01
- **Reference**: CH0008D

### RULE_009: Provider Type Exclusion
- **Description**: TX market provider specialty restrictions
- **Criteria**: Specific provider specialties (S098, S173) with certain revenue codes
- **Reference**: CH0009D

### RULE_010: HIPAA Waiver IA
- **Description**: Iowa HIPAA FP waiver exclusions
- **Reference**: FHP_PMED_MEMBER_D check

### RULE_011: Capitated Member Exclusion
- **Description**: Members with special Medicaid number
- **Criteria**: MEME_MEDCD_NO = 'AGPCLMRCOUP'

### RULE_012: Hospital Claims Filter
- **Description**: Claims starting with 'H'
- **Criteria**: LEFT(CLCL_ID, 1) = 'H'

### RULE_013: Missing Overpayment Pair
- **Description**: Reference/overpayment records without matching counterpart
- **Logic**: GROUP_ID matching

### RULE_014: MO Market Expiration
- **Description**: Missouri market expiration rules
- **Criteria**: GRGR_CK = 234 with expiration date checks
- **Reference**: CHM0021a

## Output Format

The analyzer provides:

1. **Immediate Verdict**: INCLUDED or EXCLUDED
2. **Rule-by-Rule Results**: Shows which rules caused exclusion
3. **Claim Data**: All relevant claim information
4. **GPT-4 Analysis**: Detailed explanation including:
   - Summary of exclusion reason
   - Specific rule IDs and descriptions
   - Exact data values that triggered exclusion
   - Business context explanation
   - Recommendations (if applicable)

## Example Output

```
================================================================================
ANALYZING CLAIM: CLM123456789
================================================================================

VERDICT: EXCLUDED

EXCLUSION REASONS:
  • [RULE_005] EXCLUDED: TN market (PL10), bill type 066, date 2024-08-15 > 2024-06-30

RULES PASSED: 13

GENERATING DETAILED ANALYSIS WITH GPT-4...

================================================================================
GPT-4 ANALYSIS
================================================================================

## Exclusion Summary
This claim was excluded due to Tennessee-specific business rule CHM0021b...

## Specific Rule
**RULE_005: TN Plan Specific Exclusion (CHM0021b)**

The claim met all three criteria for exclusion:
1. Market: Tennessee (GRGR_CK = 13)
2. Plan ID: PL10 (in restricted list)
3. Bill Type: 066 (Facility Type 0, Bill Class 6)
4. Service Date: 2024-08-15 (after 2024-06-30 cutoff)

## Data Points
- GRGR_CK: 13 (TN)
- CSCS_ID: PL10
- CLHP_FAC_TYPE: 0
- CLHP_BILL_CLASS: 6
- CDML_FROM_DT: 2024-08-15

## Business Explanation
This exclusion was implemented to filter out specific types of Tennessee 
claims for certain plan types after the June 30, 2024 cutoff date. This 
typically relates to changes in contract terms or benefit structures...
```

## Advanced Usage

### Batch Analysis

```python
claims_to_analyze = ['CLM001', 'CLM002', 'CLM003']

for clcl_id in claims_to_analyze:
    print(f"\n{'='*80}")
    analysis = analyzer.analyze_claim(clcl_id)
    print(analysis)
    print(f"{'='*80}\n")
```

### Custom Rule Evaluation

```python
# Run only specific checks
check_results = analyzer.run_all_checks('CLM123456789')

# Access exclusion reasons
if check_results['verdict'] == 'EXCLUDED':
    for reason in check_results['exclusion_reasons']:
        print(f"Rule: {reason['rule']}")
        print(f"Reason: {reason['reason']}")
```

### Export Results

```python
import json

check_results = analyzer.run_all_checks('CLM123456789')

# Save to JSON
with open('claim_analysis.json', 'w') as f:
    json.dump(check_results, f, indent=2, default=str)
```

## Troubleshooting

### Claim Not Found
- Verify the claim ID exists in the database
- Check you're connected to the correct database/schema
- Ensure the claim has been processed

### Missing Data
- Some fields may be NULL - this is handled gracefully
- The analyzer works with partial data where possible

### Connection Issues
- Verify Snowflake credentials
- Check warehouse is running
- Ensure network connectivity

## Performance Considerations

- **Simple checks**: Run in milliseconds
- **Complex checks**: May take 1-2 seconds (multiple DB queries)
- **GPT-4 analysis**: Typically 3-5 seconds
- **Batch processing**: Consider rate limits for large batches

## Cost Considerations

- **Snowflake**: Standard compute costs apply
- **OpenAI**: ~$0.01-0.03 per analysis (GPT-4 Turbo)
- **Optimization**: Programmatic checks run first to minimize API calls

## Extending the Analyzer

### Adding New Rules

```python
def evaluate_rule_015(self, claim_data: Dict) -> Tuple[bool, str]:
    """Your custom rule logic."""
    # Implement check
    if condition:
        return True, "Exclusion reason"
    return False, "Passed"

# Add to EXCLUSION_RULES list
```

### Custom GPT Prompts

```python
# Modify get_gpt_analysis() to customize prompting
```

## License

Internal use only - Proprietary

## Support

For questions or issues, contact the Data Analytics team.
