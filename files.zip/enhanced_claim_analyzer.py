"""
Enhanced Claim Exclusion Analyzer
Provides detailed tracing of why claims are excluded with rule-by-rule evaluation
"""

import snowflake.connector
from openai import OpenAI
import os
from typing import Dict, List, Optional, Tuple
import json
from datetime import datetime
import re

class EnhancedClaimAnalyzer:
    
    # Define all exclusion rules from the SQL
    EXCLUSION_RULES = [
        {
            'id': 'RULE_001',
            'name': 'Excluded Markets',
            'description': 'Markets excluded from analysis (NM, MD-VANT, IL, SC-BLUE, CA)',
            'sql_ref': 'Line ~800: GRGR_CK in (10,12,15,20,22)',
            'check_type': 'simple'
        },
        {
            'id': 'RULE_002',
            'name': 'Unrecoverable Disallowance Codes',
            'description': 'Claims with specific disallowance codes that are unrecoverable',
            'sql_ref': 'exclude_disall_excd table',
            'check_type': 'table_lookup'
        },
        {
            'id': 'RULE_003',
            'name': 'HMS/Connolly Line Items',
            'description': 'Claims with EOB exclusion codes FA6 or FA8',
            'sql_ref': 'CLCL_EOB_EXCD_ID in (FA6, FA8)',
            'check_type': 'simple'
        },
        {
            'id': 'RULE_004',
            'name': 'Below Payment Threshold',
            'description': 'Claims below $25 (or $10 for specific markets)',
            'sql_ref': 'CHM0005: CLCL_TOT_PAYABLE thresholds',
            'check_type': 'complex'
        },
        {
            'id': 'RULE_005',
            'name': 'TN Plan Specific Exclusion',
            'description': 'TN market with specific plan IDs, bill types, and dates after 2024-06-30',
            'sql_ref': 'CHM0021b',
            'check_type': 'complex'
        },
        {
            'id': 'RULE_006',
            'name': 'Malicious Override Codes',
            'description': 'Claims with specific override codes (J00, J01, J02, JCN, etc.)',
            'sql_ref': 'CH0009C, CHM0003b',
            'check_type': 'complex'
        },
        {
            'id': 'RULE_007',
            'name': 'Expired Claims',
            'description': 'Claims that have exceeded their expiration date based on market rules',
            'sql_ref': 'CH0006B: Expiration date logic',
            'check_type': 'very_complex'
        },
        {
            'id': 'RULE_008',
            'name': 'DC Market Date Filter',
            'description': 'DC market claims with service dates before 2017-01-01',
            'sql_ref': 'CH0008D',
            'check_type': 'simple'
        },
        {
            'id': 'RULE_009',
            'name': 'Provider Type Exclusion',
            'description': 'TX market claims with specific provider specialties and revenue codes',
            'sql_ref': 'CH0009D',
            'check_type': 'complex'
        },
        {
            'id': 'RULE_010',
            'name': 'HIPAA Waiver IA',
            'description': 'Iowa market HIPAA FP waiver exclusions',
            'sql_ref': 'FHP_PMED_MEMBER_D and IAFPWV00 plan',
            'check_type': 'complex'
        },
        {
            'id': 'RULE_011',
            'name': 'Capitated Member Exclusion',
            'description': 'Claims for members with AGPCLMRCOUP Medicaid number',
            'sql_ref': 'MEME_MEDCD_NO = AGPCLMRCOUP',
            'check_type': 'simple'
        },
        {
            'id': 'RULE_012',
            'name': 'Hospital Claims Filter',
            'description': 'Claims starting with H in claim ID',
            'sql_ref': 'left(CLCL_ID,1) = H',
            'check_type': 'simple'
        },
        {
            'id': 'RULE_013',
            'name': 'Missing Overpayment Pair',
            'description': 'Reference or overpayment records without matching counterpart',
            'sql_ref': 'GROUP_ID matching logic',
            'check_type': 'very_complex'
        },
        {
            'id': 'RULE_014',
            'name': 'MO Market Expiration',
            'description': 'Missouri market claims that expired based on paid date',
            'sql_ref': 'CHM0021a: GRGR_CK = 234',
            'check_type': 'complex'
        }
    ]
    
    def __init__(self, snowflake_config: Dict, openai_api_key: str):
        self.sf_conn = snowflake.connector.connect(**snowflake_config)
        self.client = OpenAI(api_key=openai_api_key)
        self.cursor = self.sf_conn.cursor()
    
    def evaluate_rule_001(self, claim_data: Dict) -> Tuple[bool, str]:
        """Check if claim is in excluded market."""
        grgr_ck = claim_data.get('GRGR_CK')
        excluded_markets = [10, 12, 15, 20, 22]
        
        if grgr_ck in excluded_markets:
            market_names = {10: 'NM', 12: 'MD-VANT', 15: 'VA', 20: 'VA-VANT', 22: 'Excluded market'}
            return True, f"Claim belongs to excluded market: GRGR_CK={grgr_ck} ({market_names.get(grgr_ck, 'Unknown')})"
        
        return False, "Passed: Not in excluded markets"
    
    def evaluate_rule_002(self, clcl_id: str, cdml_seq_no: int = None) -> Tuple[bool, str]:
        """Check for unrecoverable disallowance codes."""
        excluded_codes = [
            'FA5', 'FA7',  # HMS and Connolly
            'A01', 'A02', 'A03', 'A04', 'A05', 'A06', 'A07', 'A08', 'A09', 'A10',
            'A11', 'A12', 'A13', 'A14', 'A15', 'A16', 'A17', 'A18', 'A19', 'A20',
            'A21', 'A22', 'A23', 'A24', 'A25', 'A26', 'A27', 'A28', 'A29', 'A30',
            'A31', 'A32', 'A33', 'A34', 'A35', 'A36', 'A37', 'A38', 'A39', 'A40',
            'A41', 'A42', 'A43', 'A44', 'A45', 'A46', 'A47', 'A48', 'A49', 'A50',
            'A51', 'A52', 'A53', 'A54', 'A58',
            'K01', 'K02', 'K03', 'K04', 'K05', 'K06', 'K07', 'K08', 'K09', 'K10',
            'K11', 'K12', 'K13', 'K14', 'K15', 'K16', 'K17', 'K18', 'K19', 'K20',
            'K21', 'K22', 'K23', 'K24', 'K25'
        ]
        
        query = f"""
            SELECT CDML_DISALL_EXCD, CDML_SEQ_NO
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV
            WHERE CLCL_ID = '{clcl_id}'
        """
        if cdml_seq_no:
            query += f" AND CDML_SEQ_NO = {cdml_seq_no}"
        
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        for disallow_code, seq_no in results:
            if disallow_code in excluded_codes:
                return True, f"Found excluded disallowance code: {disallow_code} on line {seq_no}"
        
        return False, "Passed: No excluded disallowance codes found"
    
    def evaluate_rule_004(self, claim_data: Dict) -> Tuple[bool, str]:
        """Check payment threshold."""
        grgr_ck = claim_data.get('GRGR_CK')
        tot_payable = claim_data.get('CLCL_TOT_PAYABLE', 0)
        record_type = claim_data.get('RECORD_TYPE', 'O')
        
        # Only applies to overpayment records
        if record_type == 'R':
            return False, "Passed: Reference record not subject to threshold check"
        
        if grgr_ck in (3, 34, 13, 31):
            threshold = 10
            if tot_payable < threshold:
                return True, f"Below $10 threshold for market {grgr_ck}: ${tot_payable}"
        else:
            threshold = 25
            if tot_payable < threshold:
                return True, f"Below $25 threshold: ${tot_payable}"
        
        return False, f"Passed: Total payable ${tot_payable} meets threshold"
    
    def evaluate_rule_005(self, claim_data: Dict) -> Tuple[bool, str]:
        """Check TN market specific exclusion (CHM0021b)."""
        grgr_ck = claim_data.get('GRGR_CK')
        cscs_id = claim_data.get('CSCS_ID', '')
        cdml_from_dt = claim_data.get('CDML_FROM_DT')
        clhp_fac_type = claim_data.get('CLHP_FAC_TYPE', '')
        clhp_bill_class = claim_data.get('CLHP_BILL_CLASS', '')
        
        if grgr_ck != 13:
            return False, "Passed: Not TN market"
        
        tn_plans = ['PL10','PL11','PL12','PL95','PL96','PL97','CD04','CD05','CD06','CD07','CD08','CD09']
        if cscs_id not in tn_plans:
            return False, "Passed: Not in excluded TN plan list"
        
        bill_type = f"{clhp_fac_type}{clhp_bill_class}"
        if bill_type not in ['066', '089']:
            return False, f"Passed: Bill type {bill_type} not in exclusion list"
        
        if cdml_from_dt and cdml_from_dt > datetime(2024, 6, 30).date():
            return True, f"EXCLUDED: TN market ({cscs_id}), bill type {bill_type}, date {cdml_from_dt} > 2024-06-30"
        
        return False, "Passed: Service date before 2024-06-30 cutoff"
    
    def evaluate_rule_006(self, clcl_id: str) -> Tuple[bool, str]:
        """Check for malicious override codes."""
        excluded_override_codes = ['J00', 'J01', 'J02', 'JCN', 'YHK', 'EAM', 'G03', 'G97', 'FD3', 'FD4', 'FD5']
        
        # Check CDML
        query = f"""
            SELECT CDML_DISALL_EXCD 
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV
            WHERE CLCL_ID = '{clcl_id}'
              AND CDML_CUR_STS = '02'
              AND CDML_PR_PYMT_AMT > 0
        """
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        for (code,) in results:
            if code in excluded_override_codes:
                return True, f"Found excluded override code in CDML: {code}"
        
        # Check CDOR
        query = f"""
            SELECT EXCD_ID 
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDOR_LI_OVR_CMPCT
            WHERE CLCL_ID = '{clcl_id}'
        """
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        for (code,) in results:
            if code in excluded_override_codes:
                return True, f"Found excluded override code in CDOR: {code}"
        
        # Check CLOR
        query = f"""
            SELECT EXCD_ID 
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLOR_CL_OVR_CMPCT
            WHERE CLCL_ID = '{clcl_id}'
        """
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        for (code,) in results:
            if code in excluded_override_codes:
                return True, f"Found excluded override code in CLOR: {code}"
        
        # Check ADJ_CLM_RSN
        query = f"""
            SELECT ADJ_RSN_CD 
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.ADJ_CLM_RSN_CMPCT
            WHERE CLCL_ID = '{clcl_id}'
        """
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        for (code,) in results:
            if code in excluded_override_codes:
                return True, f"Found excluded override code in ADJ: {code}"
        
        return False, "Passed: No excluded override codes found"
    
    def run_all_checks(self, clcl_id: str, cdml_seq_no: Optional[int] = None) -> Dict:
        """Run all exclusion checks on a claim."""
        
        # First get claim data
        query = f"""
        SELECT 
            clcl.CLCL_ID,
            clcl.GRGR_CK,
            clcl.SBSB_CK,
            clcl.CLCL_CUR_STS,
            clcl.CLCL_PAID_DT,
            clcl.CLCL_RECD_DT,
            clcl.CSCS_ID,
            clcl.CLCL_TOT_PAYABLE,
            clcl.CLCL_EOB_EXCD_ID,
            cdml.CDML_SEQ_NO,
            cdml.CDML_DISALL_EXCD,
            cdml.CDML_FROM_DT,
            cdml.CDML_TO_DT,
            cdml.CDML_PR_PYMT_AMT,
            cdml.IPCD_ID,
            cdml.RCRC_ID,
            clhp.CLHP_FAC_TYPE,
            clhp.CLHP_BILL_CLASS,
            pdpd.LOBD_ID,
            meme.MEME_MEDCD_NO
        FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLCL_CLAIM_CMPCT_ACTV clcl
        LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV cdml 
            ON clcl.CLCL_ID = cdml.CLCL_ID
        LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLHP_HOSP_CMPCT_ACTV clhp 
            ON clcl.CLCL_ID = clhp.CLCL_ID
        LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_PDPD_PRODUCT_CMPCT_ACTV pdpd 
            ON clcl.PDPD_ID = pdpd.PDPD_ID
        LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_MEME_MEMBER_CMPCT_ACTV meme 
            ON cdml.MEME_CK = meme.MEME_CK
        WHERE clcl.CLCL_ID = '{clcl_id}'
        """
        
        if cdml_seq_no:
            query += f" AND cdml.CDML_SEQ_NO = {cdml_seq_no}"
        
        self.cursor.execute(query)
        columns = [col[0] for col in self.cursor.description]
        results = self.cursor.fetchall()
        
        if not results:
            return {'error': f'Claim {clcl_id} not found'}
        
        # Convert to dict (use first row if multiple line items)
        claim_data = dict(zip(columns, results[0]))
        
        # Run all checks
        check_results = {
            'claim_id': clcl_id,
            'claim_data': claim_data,
            'exclusion_reasons': [],
            'passed_rules': [],
            'verdict': 'INCLUDED'
        }
        
        # Run each rule
        excluded, msg = self.evaluate_rule_001(claim_data)
        if excluded:
            check_results['exclusion_reasons'].append({'rule': 'RULE_001', 'reason': msg})
            check_results['verdict'] = 'EXCLUDED'
        else:
            check_results['passed_rules'].append({'rule': 'RULE_001', 'message': msg})
        
        excluded, msg = self.evaluate_rule_002(clcl_id, cdml_seq_no)
        if excluded:
            check_results['exclusion_reasons'].append({'rule': 'RULE_002', 'reason': msg})
            check_results['verdict'] = 'EXCLUDED'
        else:
            check_results['passed_rules'].append({'rule': 'RULE_002', 'message': msg})
        
        excluded, msg = self.evaluate_rule_004(claim_data)
        if excluded:
            check_results['exclusion_reasons'].append({'rule': 'RULE_004', 'reason': msg})
            check_results['verdict'] = 'EXCLUDED'
        else:
            check_results['passed_rules'].append({'rule': 'RULE_004', 'message': msg})
        
        excluded, msg = self.evaluate_rule_005(claim_data)
        if excluded:
            check_results['exclusion_reasons'].append({'rule': 'RULE_005', 'reason': msg})
            check_results['verdict'] = 'EXCLUDED'
        else:
            check_results['passed_rules'].append({'rule': 'RULE_005', 'message': msg})
        
        excluded, msg = self.evaluate_rule_006(clcl_id)
        if excluded:
            check_results['exclusion_reasons'].append({'rule': 'RULE_006', 'reason': msg})
            check_results['verdict'] = 'EXCLUDED'
        else:
            check_results['passed_rules'].append({'rule': 'RULE_006', 'message': msg})
        
        return check_results
    
    def get_gpt_analysis(self, check_results: Dict) -> str:
        """Use GPT to provide comprehensive analysis."""
        
        prompt = f"""
You are analyzing why a healthcare claim was excluded from a final output table.

**Claim ID:** {check_results['claim_id']}

**Verdict:** {check_results['verdict']}

**Claim Data:**
```json
{json.dumps(check_results['claim_data'], indent=2, default=str)}
```

**Exclusion Reasons Found:**
{json.dumps(check_results['exclusion_reasons'], indent=2)}

**Rules Passed:**
{json.dumps(check_results['passed_rules'], indent=2)}

**Available Rules:**
{json.dumps(self.EXCLUSION_RULES, indent=2)}

Please provide:
1. A clear summary of why this claim was excluded (or included)
2. The specific rule(s) that caused exclusion with rule IDs
3. The exact data values that triggered the exclusion
4. Business context explanation in plain English
5. Recommendations for how to prevent similar exclusions if applicable

Format your response clearly with headers and bullet points.
"""
        
        response = self.client.chat.completions.create(
            model="gpt-4-turbo-preview",
            messages=[
                {"role": "system", "content": "You are an expert healthcare claims analyst."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2
        )
        
        return response.choices[0].message.content
    
    def analyze_claim(self, clcl_id: str, cdml_seq_no: Optional[int] = None) -> str:
        """Full analysis of a claim."""
        
        print(f"\n{'='*80}")
        print(f"ANALYZING CLAIM: {clcl_id}")
        if cdml_seq_no:
            print(f"LINE ITEM: {cdml_seq_no}")
        print(f"{'='*80}\n")
        
        # Run programmatic checks
        check_results = self.run_all_checks(clcl_id, cdml_seq_no)
        
        if 'error' in check_results:
            return check_results['error']
        
        # Print immediate results
        print(f"VERDICT: {check_results['verdict']}\n")
        
        if check_results['exclusion_reasons']:
            print("EXCLUSION REASONS:")
            for reason in check_results['exclusion_reasons']:
                print(f"  • [{reason['rule']}] {reason['reason']}")
            print()
        
        print(f"RULES PASSED: {len(check_results['passed_rules'])}")
        
        # Get GPT analysis
        print("\nGENERATING DETAILED ANALYSIS WITH GPT-4...\n")
        gpt_analysis = self.get_gpt_analysis(check_results)
        
        return gpt_analysis
    
    def close(self):
        """Close connections."""
        self.cursor.close()
        self.sf_conn.close()


# Example usage
if __name__ == "__main__":
    # Configuration
    snowflake_config = {
        'user': os.getenv('SNOWFLAKE_USER'),
        'password': os.getenv('SNOWFLAKE_PASSWORD'),
        'account': os.getenv('SNOWFLAKE_ACCOUNT'),
        'warehouse': os.getenv('SNOWFLAKE_WAREHOUSE'),
        'database': 'P01_EDL',
        'schema': 'EDL_RAWZ_CMPCT_ALLPHI'
    }
    
    openai_api_key = os.getenv('OPENAI_API_KEY')
    
    # Initialize
    analyzer = EnhancedClaimAnalyzer(snowflake_config, openai_api_key)
    
    # Analyze claim
    clcl_id = input("Enter Claim ID (CLCL_ID): ").strip()
    cdml_seq_input = input("Enter Line Sequence Number (optional, press Enter to skip): ").strip()
    cdml_seq_no = int(cdml_seq_input) if cdml_seq_input else None
    
    analysis = analyzer.analyze_claim(clcl_id, cdml_seq_no)
    
    print("\n" + "="*80)
    print("GPT-4 ANALYSIS")
    print("="*80 + "\n")
    print(analysis)
    
    # Close
    analyzer.close()
