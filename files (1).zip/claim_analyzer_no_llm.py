"""
Claim Exclusion Analyzer - No LLM Version
Provides detailed tracing of why claims are excluded using only programmatic checks
"""

import snowflake.connector
import os
from typing import Dict, List, Optional, Tuple
import json
from datetime import datetime
from collections import defaultdict

class ClaimExclusionAnalyzer:
    
    # Define all exclusion rules from the SQL
    EXCLUSION_RULES = {
        'RULE_001': {
            'name': 'Excluded Markets',
            'description': 'Markets excluded from analysis (NM, MD-VANT, IL, SC-BLUE, CA)',
            'sql_ref': 'Line ~800: GRGR_CK in (10,12,15,20,22)',
            'business_impact': 'These markets are excluded from overpayment recovery processing',
            'check_type': 'simple'
        },
        'RULE_002': {
            'name': 'Unrecoverable Disallowance Codes',
            'description': 'Claims with specific disallowance codes that are unrecoverable',
            'sql_ref': 'exclude_disall_excd table',
            'business_impact': 'Claims with appeal or plan approval codes cannot be recovered',
            'check_type': 'table_lookup'
        },
        'RULE_003': {
            'name': 'HMS/Connolly Line Items',
            'description': 'Claims with EOB exclusion codes FA6 or FA8',
            'sql_ref': 'CLCL_EOB_EXCD_ID in (FA6, FA8)',
            'business_impact': 'HMS and Connolly vendor processed claims are excluded',
            'check_type': 'simple'
        },
        'RULE_004': {
            'name': 'Below Payment Threshold',
            'description': 'Claims below $25 (or $10 for specific markets)',
            'sql_ref': 'CHM0005: CLCL_TOT_PAYABLE thresholds',
            'business_impact': 'Small dollar claims not cost-effective to pursue',
            'check_type': 'complex'
        },
        'RULE_005': {
            'name': 'TN Plan Specific Exclusion',
            'description': 'TN market with specific plan IDs, bill types, and dates after 2024-06-30',
            'sql_ref': 'CHM0021b',
            'business_impact': 'TN contract changes effective July 1, 2024',
            'check_type': 'complex'
        },
        'RULE_006': {
            'name': 'Malicious Override Codes',
            'description': 'Claims with specific override codes (J00, J01, J02, JCN, etc.)',
            'sql_ref': 'CH0009C, CHM0003b',
            'business_impact': 'Claims with manual overrides cannot be auto-recovered',
            'check_type': 'complex'
        },
        'RULE_007': {
            'name': 'Expired Claims',
            'description': 'Claims that have exceeded their expiration date based on market rules',
            'sql_ref': 'CH0006B: Expiration date logic',
            'business_impact': 'Claims past statute of limitations or contract terms',
            'check_type': 'very_complex'
        },
        'RULE_008': {
            'name': 'DC Market Date Filter',
            'description': 'DC market claims with service dates before 2017-01-01',
            'sql_ref': 'CH0008D',
            'business_impact': 'Historical claims outside recovery window',
            'check_type': 'simple'
        },
        'RULE_009': {
            'name': 'Provider Type Exclusion',
            'description': 'TX market claims with specific provider specialties and revenue codes',
            'sql_ref': 'CH0009D',
            'business_impact': 'Specific provider arrangements preclude recovery',
            'check_type': 'complex'
        },
        'RULE_010': {
            'name': 'HIPAA Waiver IA',
            'description': 'Iowa market HIPAA FP waiver exclusions',
            'sql_ref': 'FHP_PMED_MEMBER_D and IAFPWV00 plan',
            'business_impact': 'Members with HIPAA waivers protected from recovery',
            'check_type': 'complex'
        },
        'RULE_011': {
            'name': 'Capitated Member Exclusion',
            'description': 'Claims for members with AGPCLMRCOUP Medicaid number',
            'sql_ref': 'MEME_MEDCD_NO = AGPCLMRCOUP',
            'business_impact': 'Capitated arrangements already reconciled',
            'check_type': 'simple'
        },
        'RULE_012': {
            'name': 'Hospital Claims Filter',
            'description': 'Claims starting with H in claim ID',
            'sql_ref': 'left(CLCL_ID,1) = H',
            'business_impact': 'Specific claim type excluded from process',
            'check_type': 'simple'
        },
        'RULE_013': {
            'name': 'Missing Overpayment Pair',
            'description': 'Reference or overpayment records without matching counterpart',
            'sql_ref': 'GROUP_ID matching logic',
            'business_impact': 'Cannot identify recovery without paired transactions',
            'check_type': 'very_complex'
        },
        'RULE_014': {
            'name': 'MO Market Expiration',
            'description': 'Missouri market claims that expired based on paid date',
            'sql_ref': 'CHM0021a: GRGR_CK = 234',
            'business_impact': 'Market-specific expiration rules',
            'check_type': 'complex'
        }
    }
    
    def __init__(self, snowflake_config: Dict):
        self.sf_conn = snowflake.connector.connect(**snowflake_config)
        self.cursor = self.sf_conn.cursor()
    
    def evaluate_rule_001(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check if claim is in excluded market."""
        grgr_ck = claim_data.get('GRGR_CK')
        excluded_markets = {
            10: 'NM',
            12: 'MD-VANT',
            15: 'VA',
            20: 'VA-VANT',
            22: 'Excluded market'
        }
        
        if grgr_ck in excluded_markets:
            details = {
                'grgr_ck': grgr_ck,
                'market_name': excluded_markets[grgr_ck],
                'reason': f"Market {excluded_markets[grgr_ck]} is excluded from overpayment processing"
            }
            return True, f"Claim belongs to excluded market: GRGR_CK={grgr_ck} ({excluded_markets[grgr_ck]})", details
        
        return False, "Passed: Not in excluded markets", {}
    
    def evaluate_rule_002(self, clcl_id: str, cdml_seq_no: int = None) -> Tuple[bool, str, Dict]:
        """Check for unrecoverable disallowance codes."""
        excluded_codes = {
            'FA5': 'line item HMS',
            'FA7': 'line item Connolly',
            'A01': 'ProcessedPerAppeal', 'A02': 'ProcessedPerAppeal', 'A03': 'ProcessedPerAppeal',
            'A04': 'ProcessedPerAppeal', 'A05': 'ProcessedPerAppeal', 'A06': 'ProcessedPerAppeal',
            'A07': 'ProcessedPerAppeal', 'A08': 'ProcessedPerAppeal', 'A09': 'ProcessedPerAppeal',
            'A10': 'ProcessedPerAppeal', 'A11': 'ProcessedPerAppeal', 'A12': 'ProcessedPerAppeal',
            'A13': 'ProcessedPerAppeal', 'A14': 'ProcessedPerAppeal', 'A15': 'ProcessedPerAppeal',
            'A16': 'ProcessedPerAppeal', 'A17': 'ProcessedPerAppeal', 'A18': 'ProcessedPerAppeal',
            'A19': 'ProcessedPerAppeal', 'A20': 'ProcessedPerAppeal', 'A21': 'ProcessedPerAppeal',
            'A22': 'ProcessedPerAppeal', 'A23': 'ProcessedPerAppeal', 'A24': 'ProcessedPerAppeal',
            'A25': 'ProcessedPerAppeal', 'A26': 'ProcessedPerAppeal', 'A27': 'AddlPaymentOnAppeal',
            'A28': 'AddlPaymentOnAppeal', 'A29': 'AddlPaymentOnAppeal', 'A30': 'AddlPaymentOnAppeal',
            'A31': 'AddlPaymentOnAppeal', 'A32': 'AddlPaymentOnAppeal', 'A33': 'AddlPaymentOnAppeal',
            'A34': 'AddlPaymentOnAppeal', 'A35': 'AddlPaymentOnAppeal', 'A36': 'AddlPaymentOnAppeal',
            'A37': 'AddlPaymentOnAppeal', 'A38': 'AddlPaymentOnAppeal', 'A39': 'AddlPaymentOnAppeal',
            'A40': 'AddlPaymentOnAppeal', 'A41': 'AddlPaymentOnAppeal', 'A42': 'AddlPaymentOnAppeal',
            'A43': 'AddlPaymentOnAppeal', 'A44': 'AddlPaymentOnAppeal', 'A45': 'AddlPaymentOnAppeal',
            'A46': 'AddlPaymentOnAppeal', 'A47': 'AddlPaymentOnAppeal', 'A48': 'AddlPaymentOnAppeal',
            'A49': 'AddlPaymentOnAppeal', 'A50': 'AddlPaymentOnAppeal', 'A51': 'AddlPaymentOnAppeal',
            'A52': 'AddlPaymentOnAppeal', 'A53': 'AppealDisallowed', 'A54': 'DenialUpheldOnAppeal',
            'A58': '72HourEligibility',
            'K01': 'PaidPerPlanApproval', 'K02': 'PaidPerPlanApproval', 'K03': 'PaidPerPlanApproval',
            'K04': 'PaidPerPlanApproval', 'K05': 'PaidPerPlanApproval', 'K06': 'PaidPerPlanApproval',
            'K07': 'PaidPerPlanApproval', 'K08': 'PaidPerPlanApproval', 'K09': 'PaidPerPlanApproval',
            'K10': 'PaidPerPlanApproval', 'K11': 'PaidPerPlanApproval', 'K12': 'PaidPerPlanApproval',
            'K13': 'PaidPerPlanApproval', 'K14': 'PaidPerPlanApproval', 'K15': 'PaidPerPlanApproval',
            'K16': 'PaidPerPlanApproval', 'K17': 'PaidPerPlanApproval', 'K18': 'PaidPerPlanApproval',
            'K19': 'PaidPerPlanApproval', 'K20': 'PaidPerPlanApproval', 'K21': 'PaidPerPlanApproval',
            'K22': 'PaidPerPlanApproval', 'K23': 'PaidPerPlanApproval', 'K24': 'PaidPerPlanApproval',
            'K25': 'PaidPerPlanApproval'
        }
        
        query = f"""
            SELECT CDML_DISALL_EXCD, CDML_SEQ_NO
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV
            WHERE CLCL_ID = '{clcl_id}'
        """
        if cdml_seq_no:
            query += f" AND CDML_SEQ_NO = {cdml_seq_no}"
        
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        for disallow_code, seq_no in results:
            if disallow_code in excluded_codes:
                details = {
                    'disallow_code': disallow_code,
                    'code_category': excluded_codes[disallow_code],
                    'line_number': seq_no,
                    'reason': f"Code indicates {excluded_codes[disallow_code]} - cannot be recovered"
                }
                return True, f"Found excluded disallowance code: {disallow_code} ({excluded_codes[disallow_code]}) on line {seq_no}", details
        
        return False, "Passed: No excluded disallowance codes found", {}
    
    def evaluate_rule_003(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check for HMS/Connolly exclusion codes."""
        eob_code = claim_data.get('CLCL_EOB_EXCD_ID')
        
        if eob_code in ('FA6', 'FA8'):
            vendor = 'HMS' if eob_code == 'FA6' else 'Connolly'
            details = {
                'eob_code': eob_code,
                'vendor': vendor,
                'reason': f"Claim processed by {vendor} - excluded from internal recovery"
            }
            return True, f"Claim has {vendor} exclusion code: {eob_code}", details
        
        return False, "Passed: No HMS/Connolly exclusion codes", {}
    
    def evaluate_rule_004(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check payment threshold."""
        grgr_ck = claim_data.get('GRGR_CK')
        tot_payable = claim_data.get('CLCL_TOT_PAYABLE', 0)
        record_type = claim_data.get('RECORD_TYPE', 'O')
        
        # Only applies to overpayment records
        if record_type == 'R':
            return False, "Passed: Reference record not subject to threshold check", {}
        
        if grgr_ck in (3, 34, 13, 31):
            threshold = 10
            market_type = "FL, KY, TN, VA-MM"
            if tot_payable < threshold:
                details = {
                    'grgr_ck': grgr_ck,
                    'total_payable': tot_payable,
                    'threshold': threshold,
                    'market_type': market_type,
                    'reason': f"Claims below ${threshold} not cost-effective to pursue for {market_type} markets"
                }
                return True, f"Below ${threshold} threshold for market {grgr_ck}: ${tot_payable:.2f}", details
        else:
            threshold = 25
            if tot_payable < threshold:
                details = {
                    'grgr_ck': grgr_ck,
                    'total_payable': tot_payable,
                    'threshold': threshold,
                    'reason': f"Claims below ${threshold} not cost-effective to pursue"
                }
                return True, f"Below ${threshold} threshold: ${tot_payable:.2f}", details
        
        return False, f"Passed: Total payable ${tot_payable:.2f} meets threshold", {}
    
    def evaluate_rule_005(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check TN market specific exclusion (CHM0021b)."""
        grgr_ck = claim_data.get('GRGR_CK')
        cscs_id = claim_data.get('CSCS_ID', '')
        cdml_from_dt = claim_data.get('CDML_FROM_DT')
        clhp_fac_type = claim_data.get('CLHP_FAC_TYPE', '')
        clhp_bill_class = claim_data.get('CLHP_BILL_CLASS', '')
        
        if grgr_ck != 13:
            return False, "Passed: Not TN market", {}
        
        tn_plans = ['PL10','PL11','PL12','PL95','PL96','PL97','CD04','CD05','CD06','CD07','CD08','CD09']
        if cscs_id not in tn_plans:
            return False, "Passed: Not in excluded TN plan list", {}
        
        bill_type = f"{clhp_fac_type}{clhp_bill_class}"
        if bill_type not in ['066', '089']:
            return False, f"Passed: Bill type {bill_type} not in exclusion list", {}
        
        cutoff_date = datetime(2024, 6, 30).date()
        if cdml_from_dt and cdml_from_dt > cutoff_date:
            details = {
                'grgr_ck': grgr_ck,
                'market': 'Tennessee',
                'cscs_id': cscs_id,
                'bill_type': bill_type,
                'service_date': str(cdml_from_dt),
                'cutoff_date': '2024-06-30',
                'reason': 'TN contract changes effective July 1, 2024 exclude these claims from recovery'
            }
            return True, f"EXCLUDED: TN market ({cscs_id}), bill type {bill_type}, date {cdml_from_dt} > 2024-06-30", details
        
        return False, "Passed: Service date before 2024-06-30 cutoff", {}
    
    def evaluate_rule_006(self, clcl_id: str) -> Tuple[bool, str, Dict]:
        """Check for malicious override codes."""
        excluded_override_codes = {
            'J00': 'Manual override code', 
            'J01': 'Manual override code', 
            'J02': 'Manual override code', 
            'JCN': 'Manual override code',
            'YHK': 'Manual override code', 
            'EAM': 'Manual override code', 
            'G03': 'Manual override code', 
            'G97': 'Manual override code',
            'FD3': 'Manual override code', 
            'FD4': 'Manual override code', 
            'FD5': 'Manual override code'
        }
        
        found_codes = []
        
        # Check CDML
        query = f"""
            SELECT CDML_DISALL_EXCD 
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV
            WHERE CLCL_ID = '{clcl_id}'
              AND CDML_CUR_STS = '02'
              AND CDML_PR_PYMT_AMT > 0
        """
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        for (code,) in results:
            if code in excluded_override_codes:
                found_codes.append({'source': 'CDML', 'code': code, 'description': excluded_override_codes[code]})
        
        # Check CDOR
        query = f"""
            SELECT EXCD_ID 
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDOR_LI_OVR_CMPCT
            WHERE CLCL_ID = '{clcl_id}'
        """
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        for (code,) in results:
            if code in excluded_override_codes:
                found_codes.append({'source': 'CDOR (Line Override)', 'code': code, 'description': excluded_override_codes[code]})
        
        # Check CLOR
        query = f"""
            SELECT EXCD_ID 
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLOR_CL_OVR_CMPCT
            WHERE CLCL_ID = '{clcl_id}'
        """
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        for (code,) in results:
            if code in excluded_override_codes:
                found_codes.append({'source': 'CLOR (Claim Override)', 'code': code, 'description': excluded_override_codes[code]})
        
        # Check ADJ_CLM_RSN
        query = f"""
            SELECT ADJ_RSN_CD 
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.ADJ_CLM_RSN_CMPCT
            WHERE CLCL_ID = '{clcl_id}'
        """
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        for (code,) in results:
            if code in excluded_override_codes:
                found_codes.append({'source': 'ADJ (Adjustment Reason)', 'code': code, 'description': excluded_override_codes[code]})
        
        if found_codes:
            details = {
                'override_codes': found_codes,
                'reason': 'Claims with manual overrides cannot be automatically recovered'
            }
            msg = f"Found {len(found_codes)} excluded override code(s): " + ", ".join([f"{c['code']} in {c['source']}" for c in found_codes])
            return True, msg, details
        
        return False, "Passed: No excluded override codes found", {}
    
    def evaluate_rule_008(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check DC market date filter."""
        grgr_ck = claim_data.get('GRGR_CK')
        cdml_from_dt = claim_data.get('CDML_FROM_DT')
        record_type = claim_data.get('RECORD_TYPE', 'O')
        
        if record_type == 'R':
            return False, "Passed: Reference record not subject to date filter", {}
        
        if grgr_ck == 6:
            cutoff_date = datetime(2017, 1, 1).date()
            if cdml_from_dt and cdml_from_dt < cutoff_date:
                details = {
                    'grgr_ck': grgr_ck,
                    'market': 'DC',
                    'service_date': str(cdml_from_dt),
                    'cutoff_date': '2017-01-01',
                    'reason': 'DC market claims before 2017 are outside recovery window'
                }
                return True, f"DC market claim with service date {cdml_from_dt} before 2017-01-01", details
        
        return False, "Passed: Not DC market or date within range", {}
    
    def evaluate_rule_011(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check for capitated member exclusion."""
        medcd_no = claim_data.get('MEME_MEDCD_NO', '')
        
        if medcd_no == 'AGPCLMRCOUP':
            details = {
                'medicaid_number': 'AGPCLMRCOUP',
                'reason': 'Member has capitated arrangement - claims already reconciled'
            }
            return True, "Member has capitated exclusion code (AGPCLMRCOUP)", details
        
        return False, "Passed: Not a capitated member", {}
    
    def evaluate_rule_012(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check hospital claims filter."""
        clcl_id = claim_data.get('CLCL_ID', '')
        
        if clcl_id.startswith('H'):
            details = {
                'clcl_id': clcl_id,
                'reason': 'Hospital claim type excluded from this process'
            }
            return True, f"Claim ID starts with 'H': {clcl_id}", details
        
        return False, "Passed: Not a hospital claim", {}
    
    def get_claim_data(self, clcl_id: str, cdml_seq_no: Optional[int] = None) -> List[Dict]:
        """Fetch comprehensive claim data from Snowflake tables."""
        
        query = f"""
        SELECT 
            clcl.CLCL_ID,
            clcl.GRGR_CK,
            clcl.SBSB_CK,
            clcl.CLCL_CUR_STS,
            clcl.CLCL_PAID_DT,
            clcl.CLCL_RECD_DT,
            clcl.CSCS_ID,
            clcl.CLCL_TOT_PAYABLE,
            clcl.CLCL_EOB_EXCD_ID,
            clcl.PDPD_ID,
            cdml.CDML_SEQ_NO,
            cdml.CDML_DISALL_EXCD,
            cdml.CDML_FROM_DT,
            cdml.CDML_TO_DT,
            cdml.CDML_PR_PYMT_AMT,
            cdml.IPCD_ID,
            cdml.RCRC_ID,
            cdml.MEME_CK,
            clhp.CLHP_FAC_TYPE,
            clhp.CLHP_BILL_CLASS,
            pdpd.LOBD_ID,
            meme.MEME_MEDCD_NO
        FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLCL_CLAIM_CMPCT_ACTV clcl
        LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV cdml 
            ON clcl.CLCL_ID = cdml.CLCL_ID
        LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLHP_HOSP_CMPCT_ACTV clhp 
            ON clcl.CLCL_ID = clhp.CLCL_ID
        LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_PDPD_PRODUCT_CMPCT_ACTV pdpd 
            ON clcl.PDPD_ID = pdpd.PDPD_ID
        LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_MEME_MEMBER_CMPCT_ACTV meme 
            ON cdml.MEME_CK = meme.MEME_CK
        WHERE clcl.CLCL_ID = '{clcl_id}'
        """
        
        if cdml_seq_no:
            query += f" AND cdml.CDML_SEQ_NO = {cdml_seq_no}"
        
        self.cursor.execute(query)
        columns = [col[0] for col in self.cursor.description]
        results = self.cursor.fetchall()
        
        if not results:
            return []
        
        # Convert to list of dicts
        claim_data = []
        for row in results:
            claim_data.append(dict(zip(columns, row)))
        
        return claim_data
    
    def run_all_checks(self, clcl_id: str, cdml_seq_no: Optional[int] = None) -> Dict:
        """Run all exclusion checks on a claim."""
        
        # Get claim data
        claim_data_list = self.get_claim_data(clcl_id, cdml_seq_no)
        
        if not claim_data_list:
            return {'error': f'Claim {clcl_id} not found'}
        
        # Use first row for claim-level checks (usually all rows have same claim-level data)
        claim_data = claim_data_list[0]
        
        check_results = {
            'claim_id': clcl_id,
            'cdml_seq_no': cdml_seq_no,
            'claim_data': claim_data,
            'exclusion_reasons': [],
            'passed_rules': [],
            'verdict': 'INCLUDED',
            'line_items_checked': len(claim_data_list)
        }
        
        # Run each rule
        rules_to_check = [
            ('RULE_001', lambda: self.evaluate_rule_001(claim_data)),
            ('RULE_002', lambda: self.evaluate_rule_002(clcl_id, cdml_seq_no)),
            ('RULE_003', lambda: self.evaluate_rule_003(claim_data)),
            ('RULE_004', lambda: self.evaluate_rule_004(claim_data)),
            ('RULE_005', lambda: self.evaluate_rule_005(claim_data)),
            ('RULE_006', lambda: self.evaluate_rule_006(clcl_id)),
            ('RULE_008', lambda: self.evaluate_rule_008(claim_data)),
            ('RULE_011', lambda: self.evaluate_rule_011(claim_data)),
            ('RULE_012', lambda: self.evaluate_rule_012(claim_data)),
        ]
        
        for rule_id, check_func in rules_to_check:
            try:
                excluded, msg, details = check_func()
                if excluded:
                    rule_info = self.EXCLUSION_RULES[rule_id]
                    check_results['exclusion_reasons'].append({
                        'rule_id': rule_id,
                        'rule_name': rule_info['name'],
                        'message': msg,
                        'details': details,
                        'sql_reference': rule_info['sql_ref'],
                        'business_impact': rule_info['business_impact']
                    })
                    check_results['verdict'] = 'EXCLUDED'
                else:
                    check_results['passed_rules'].append({
                        'rule_id': rule_id,
                        'rule_name': self.EXCLUSION_RULES[rule_id]['name'],
                        'message': msg
                    })
            except Exception as e:
                check_results['passed_rules'].append({
                    'rule_id': rule_id,
                    'rule_name': self.EXCLUSION_RULES[rule_id]['name'],
                    'message': f"Error checking rule: {str(e)}"
                })
        
        return check_results
    
    def format_analysis_report(self, check_results: Dict) -> str:
        """Format the analysis results into a readable report."""
        
        if 'error' in check_results:
            return check_results['error']
        
        report = []
        report.append("=" * 80)
        report.append("CLAIM EXCLUSION ANALYSIS REPORT")
        report.append("=" * 80)
        report.append("")
        
        # Claim Info
        report.append("CLAIM INFORMATION:")
        report.append(f"  Claim ID: {check_results['claim_id']}")
        if check_results.get('cdml_seq_no'):
            report.append(f"  Line Sequence: {check_results['cdml_seq_no']}")
        report.append(f"  Line Items Checked: {check_results['line_items_checked']}")
        report.append("")
        
        # Key Claim Data
        claim_data = check_results['claim_data']
        report.append("KEY CLAIM DATA:")
        report.append(f"  Market (GRGR_CK): {claim_data.get('GRGR_CK')}")
        report.append(f"  Plan ID (CSCS_ID): {claim_data.get('CSCS_ID')}")
        report.append(f"  Total Payable: ${claim_data.get('CLCL_TOT_PAYABLE', 0):.2f}")
        report.append(f"  Service Date: {claim_data.get('CDML_FROM_DT')}")
        report.append(f"  Paid Date: {claim_data.get('CLCL_PAID_DT')}")
        if claim_data.get('CLHP_FAC_TYPE') or claim_data.get('CLHP_BILL_CLASS'):
            report.append(f"  Bill Type: {claim_data.get('CLHP_FAC_TYPE', '')}{claim_data.get('CLHP_BILL_CLASS', '')}")
        report.append("")
        
        # Verdict
        report.append("=" * 80)
        report.append(f"VERDICT: {check_results['verdict']}")
        report.append("=" * 80)
        report.append("")
        
        # Exclusion Reasons
        if check_results['exclusion_reasons']:
            report.append("EXCLUSION REASONS:")
            report.append("")
            
            for i, reason in enumerate(check_results['exclusion_reasons'], 1):
                report.append(f"{i}. [{reason['rule_id']}] {reason['rule_name']}")
                report.append(f"   Message: {reason['message']}")
                report.append(f"   SQL Reference: {reason['sql_reference']}")
                report.append(f"   Business Impact: {reason['business_impact']}")
                
                if reason['details']:
                    report.append("   Details:")
                    for key, value in reason['details'].items():
                        if key != 'reason':
                            report.append(f"     - {key}: {value}")
                    if 'reason' in reason['details']:
                        report.append(f"   Explanation: {reason['details']['reason']}")
                report.append("")
        else:
            report.append("✓ No exclusion reasons found - claim would be INCLUDED in final output")
            report.append("")
        
        # Rules Passed
        report.append(f"RULES PASSED: {len(check_results['passed_rules'])}")
        report.append("")
        for rule in check_results['passed_rules']:
            report.append(f"  ✓ [{rule['rule_id']}] {rule['rule_name']}")
            report.append(f"    {rule['message']}")
        
        report.append("")
        report.append("=" * 80)
        report.append("END OF REPORT")
        report.append("=" * 80)
        
        return "\n".join(report)
    
    def analyze_claim(self, clcl_id: str, cdml_seq_no: Optional[int] = None, 
                     output_format: str = 'report') -> str:
        """
        Full analysis of a claim.
        
        Args:
            clcl_id: Claim ID to analyze
            cdml_seq_no: Optional line sequence number
            output_format: 'report' for formatted report, 'json' for JSON output
        
        Returns:
            Formatted analysis string
        """
        
        check_results = self.run_all_checks(clcl_id, cdml_seq_no)
        
        if output_format == 'json':
            return json.dumps(check_results, indent=2, default=str)
        else:
            return self.format_analysis_report(check_results)
    
    def analyze_multiple_claims(self, claim_ids: List[str]) -> Dict[str, Dict]:
        """Analyze multiple claims and return summary statistics."""
        
        results = {}
        summary = {
            'total_claims': len(claim_ids),
            'excluded_claims': 0,
            'included_claims': 0,
            'exclusion_by_rule': defaultdict(int),
            'errors': 0
        }
        
        for clcl_id in claim_ids:
            check_results = self.run_all_checks(clcl_id)
            results[clcl_id] = check_results
            
            if 'error' in check_results:
                summary['errors'] += 1
            elif check_results['verdict'] == 'EXCLUDED':
                summary['excluded_claims'] += 1
                for reason in check_results['exclusion_reasons']:
                    summary['exclusion_by_rule'][reason['rule_id']] += 1
            else:
                summary['included_claims'] += 1
        
        return {
            'summary': dict(summary),
            'details': results
        }
    
    def close(self):
        """Close database connections."""
        self.cursor.close()
        self.sf_conn.close()


# Example usage
if __name__ == "__main__":
    # Configuration
    snowflake_config = {
        'user': os.getenv('SNOWFLAKE_USER'),
        'password': os.getenv('SNOWFLAKE_PASSWORD'),
        'account': os.getenv('SNOWFLAKE_ACCOUNT'),
        'warehouse': os.getenv('SNOWFLAKE_WAREHOUSE'),
        'database': 'P01_EDL',
        'schema': 'EDL_RAWZ_CMPCT_ALLPHI'
    }
    
    # Initialize
    analyzer = ClaimExclusionAnalyzer(snowflake_config)
    
    # Interactive mode
    print("\n" + "=" * 80)
    print("CLAIM EXCLUSION ANALYZER (No LLM)")
    print("=" * 80 + "\n")
    
    while True:
        clcl_id = input("\nEnter Claim ID (CLCL_ID) or 'quit' to exit: ").strip()
        
        if clcl_id.lower() in ('quit', 'exit', 'q'):
            break
        
        if not clcl_id:
            continue
        
        cdml_seq_input = input("Enter Line Sequence Number (optional, press Enter to skip): ").strip()
        cdml_seq_no = int(cdml_seq_input) if cdml_seq_input else None
        
        # Analyze and display
        report = analyzer.analyze_claim(clcl_id, cdml_seq_no)
        print("\n" + report)
        
        # Ask if user wants JSON output too
        json_output = input("\nWould you like JSON output? (y/n): ").strip().lower()
        if json_output == 'y':
            json_report = analyzer.analyze_claim(clcl_id, cdml_seq_no, output_format='json')
            print("\nJSON OUTPUT:")
            print(json_report)
    
    # Close
    analyzer.close()
    print("\nAnalyzer closed. Goodbye!")
