# Claim Exclusion Analyzer (No LLM Version)

A purely programmatic analyzer that identifies why healthcare claims are excluded from the final output table. This version uses **NO LLM/AI** - all analysis is done through direct SQL queries and Python logic.

## Features

- ✅ **No External Dependencies on AI Services**: Pure programmatic analysis
- ✅ **Fast**: No API calls, instant results
- ✅ **Cost-Free**: No OpenAI costs
- ✅ **Deterministic**: Same input always produces same output
- ✅ **Detailed Reports**: Comprehensive human-readable analysis
- ✅ **JSON Export**: Machine-readable output for integration
- ✅ **Batch Processing**: Analyze multiple claims with summary statistics

## Installation

```bash
pip install snowflake-connector-python python-dotenv
```

## Environment Setup

Create a `.env` file with your Snowflake credentials:

```env
SNOWFLAKE_USER=your_username
SNOWFLAKE_PASSWORD=your_password
SNOWFLAKE_ACCOUNT=your_account
SNOWFLAKE_WAREHOUSE=your_warehouse
```

## Quick Start

### Interactive Mode

```bash
python claim_analyzer_no_llm.py
```

You'll be prompted to enter:
1. Claim ID (CLCL_ID)
2. Line Sequence Number (optional)
3. Whether you want JSON output

### Programmatic Usage

```python
from claim_analyzer_no_llm import ClaimExclusionAnalyzer
import os
from dotenv import load_dotenv

load_dotenv()

# Configuration
snowflake_config = {
    'user': os.getenv('SNOWFLAKE_USER'),
    'password': os.getenv('SNOWFLAKE_PASSWORD'),
    'account': os.getenv('SNOWFLAKE_ACCOUNT'),
    'warehouse': os.getenv('SNOWFLAKE_WAREHOUSE'),
    'database': 'P01_EDL',
    'schema': 'EDL_RAWZ_CMPCT_ALLPHI'
}

# Initialize analyzer
analyzer = ClaimExclusionAnalyzer(snowflake_config)

# Analyze a single claim
report = analyzer.analyze_claim('CLM123456789')
print(report)

# Get JSON output instead
json_output = analyzer.analyze_claim('CLM123456789', output_format='json')
print(json_output)

# Analyze multiple claims
results = analyzer.analyze_multiple_claims(['CLM001', 'CLM002', 'CLM003'])
print(f"Excluded: {results['summary']['excluded_claims']}")
print(f"Included: {results['summary']['included_claims']}")

# Clean up
analyzer.close()
```

## Rules Checked

The analyzer checks the following exclusion rules:

| Rule ID | Name | Description |
|---------|------|-------------|
| RULE_001 | Excluded Markets | Markets 10, 12, 15, 20, 22 |
| RULE_002 | Unrecoverable Disallowance Codes | FA5, FA7, A01-A58, K01-K25 |
| RULE_003 | HMS/Connolly Line Items | EOB codes FA6, FA8 |
| RULE_004 | Below Payment Threshold | <$25 (or <$10 for specific markets) |
| RULE_005 | TN Plan Specific Exclusion | TN market, specific plans, dates after 2024-06-30 |
| RULE_006 | Malicious Override Codes | J00, J01, J02, JCN, YHK, etc. |
| RULE_008 | DC Market Date Filter | DC claims before 2017-01-01 |
| RULE_011 | Capitated Member Exclusion | MEME_MEDCD_NO = AGPCLMRCOUP |
| RULE_012 | Hospital Claims Filter | Claim ID starts with 'H' |

## Example Output

```
================================================================================
CLAIM EXCLUSION ANALYSIS REPORT
================================================================================

CLAIM INFORMATION:
  Claim ID: CLM123456789
  Line Items Checked: 1

KEY CLAIM DATA:
  Market (GRGR_CK): 13
  Plan ID (CSCS_ID): PL10
  Total Payable: $150.00
  Service Date: 2024-08-15
  Paid Date: 2024-08-20
  Bill Type: 066

================================================================================
VERDICT: EXCLUDED
================================================================================

EXCLUSION REASONS:

1. [RULE_005] TN Plan Specific Exclusion
   Message: EXCLUDED: TN market (PL10), bill type 066, date 2024-08-15 > 2024-06-30
   SQL Reference: CHM0021b
   Business Impact: TN contract changes effective July 1, 2024
   Details:
     - grgr_ck: 13
     - market: Tennessee
     - cscs_id: PL10
     - bill_type: 066
     - service_date: 2024-08-15
     - cutoff_date: 2024-06-30
   Explanation: TN contract changes effective July 1, 2024 exclude these claims from recovery

RULES PASSED: 8

  ✓ [RULE_001] Excluded Markets
    Passed: Not in excluded markets
  ✓ [RULE_002] Unrecoverable Disallowance Codes
    Passed: No excluded disallowance codes found
  ✓ [RULE_003] HMS/Connolly Line Items
    Passed: No HMS/Connolly exclusion codes
  ✓ [RULE_004] Below Payment Threshold
    Passed: Total payable $150.00 meets threshold
  ✓ [RULE_006] Malicious Override Codes
    Passed: No excluded override codes found
  ✓ [RULE_008] DC Market Date Filter
    Passed: Not DC market or date within range
  ✓ [RULE_011] Capitated Member Exclusion
    Passed: Not a capitated member
  ✓ [RULE_012] Hospital Claims Filter
    Passed: Not a hospital claim

================================================================================
END OF REPORT
================================================================================
```

## JSON Output Format

```json
{
  "claim_id": "CLM123456789",
  "cdml_seq_no": null,
  "verdict": "EXCLUDED",
  "line_items_checked": 1,
  "exclusion_reasons": [
    {
      "rule_id": "RULE_005",
      "rule_name": "TN Plan Specific Exclusion",
      "message": "EXCLUDED: TN market (PL10), bill type 066, date 2024-08-15 > 2024-06-30",
      "details": {
        "grgr_ck": 13,
        "market": "Tennessee",
        "cscs_id": "PL10",
        "bill_type": "066",
        "service_date": "2024-08-15",
        "cutoff_date": "2024-06-30",
        "reason": "TN contract changes effective July 1, 2024 exclude these claims from recovery"
      },
      "sql_reference": "CHM0021b",
      "business_impact": "TN contract changes effective July 1, 2024"
    }
  ],
  "passed_rules": [
    {
      "rule_id": "RULE_001",
      "rule_name": "Excluded Markets",
      "message": "Passed: Not in excluded markets"
    }
  ],
  "claim_data": {
    "CLCL_ID": "CLM123456789",
    "GRGR_CK": 13,
    "CSCS_ID": "PL10",
    "CLCL_TOT_PAYABLE": 150.00,
    "CDML_FROM_DT": "2024-08-15",
    "CLHP_FAC_TYPE": "0",
    "CLHP_BILL_CLASS": "6"
  }
}
```

## Batch Processing

```python
# Analyze multiple claims
claim_list = ['CLM001', 'CLM002', 'CLM003', 'CLM004', 'CLM005']
results = analyzer.analyze_multiple_claims(claim_list)

# Print summary
print(f"Total Claims: {results['summary']['total_claims']}")
print(f"Excluded: {results['summary']['excluded_claims']}")
print(f"Included: {results['summary']['included_claims']}")
print(f"Errors: {results['summary']['errors']}")

# Print exclusion breakdown
print("\nExclusions by Rule:")
for rule_id, count in results['summary']['exclusion_by_rule'].items():
    print(f"  {rule_id}: {count} claims")

# Access individual results
for clcl_id, result in results['details'].items():
    if result['verdict'] == 'EXCLUDED':
        print(f"\n{clcl_id}: {len(result['exclusion_reasons'])} reasons")
```

## Export to File

```python
import json

# Analyze claim
check_results = analyzer.run_all_checks('CLM123456789')

# Save as JSON
with open('claim_analysis.json', 'w') as f:
    json.dump(check_results, f, indent=2, default=str)

# Save formatted report
report = analyzer.analyze_claim('CLM123456789')
with open('claim_report.txt', 'w') as f:
    f.write(report)
```

## Adding Custom Rules

Extend the analyzer by adding your own rules:

```python
def evaluate_rule_015(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
    """Check for your custom exclusion logic."""
    
    # Your logic here
    if some_condition:
        details = {
            'field1': value1,
            'field2': value2,
            'reason': 'Explanation of why excluded'
        }
        return True, "Brief message", details
    
    return False, "Passed: Your rule description", {}

# Add to EXCLUSION_RULES dictionary
EXCLUSION_RULES['RULE_015'] = {
    'name': 'Your Rule Name',
    'description': 'What this rule checks',
    'sql_ref': 'Reference to SQL code',
    'business_impact': 'Why this matters',
    'check_type': 'complex'
}

# Add to rules_to_check list in run_all_checks()
rules_to_check.append(('RULE_015', lambda: self.evaluate_rule_015(claim_data)))
```

## Performance

- **Single Claim Analysis**: 0.5-2 seconds (depending on rule complexity)
- **Batch Processing**: ~1-2 seconds per claim
- **No API Costs**: Zero external API calls
- **Database Impact**: Minimal (uses indexes, efficient queries)

## Advantages Over LLM Version

| Feature | No LLM | With LLM |
|---------|--------|----------|
| Speed | ⚡ Instant | 🐢 3-5 seconds |
| Cost | 💰 Free | 💸 $0.01-0.03/claim |
| Consistency | ✅ Always same | ❓ May vary |
| Explanation Quality | ✅ Structured | ✅✅ Natural language |
| Offline Capability | ✅ Yes | ❌ No |
| Dependencies | ✅ Only Snowflake | ❌ OpenAI required |

## Troubleshooting

### "Claim not found"
- Verify claim ID exists
- Check database/schema configuration
- Ensure warehouse is active

### "Error checking rule"
- Check database permissions
- Verify all required tables exist
- Review error message in passed_rules section

### Slow Performance
- Check Snowflake warehouse size
- Verify network connectivity
- Consider increasing warehouse for batch jobs

## Integration Examples

### REST API Wrapper

```python
from flask import Flask, jsonify, request

app = Flask(__name__)
analyzer = ClaimExclusionAnalyzer(snowflake_config)

@app.route('/analyze/<clcl_id>')
def analyze(clcl_id):
    result = analyzer.run_all_checks(clcl_id)
    return jsonify(result)

if __name__ == '__main__':
    app.run(port=5000)
```

### Scheduled Batch Job

```python
import schedule
import time

def daily_analysis():
    # Get claims from yesterday
    claims = get_yesterday_claims()
    results = analyzer.analyze_multiple_claims(claims)
    
    # Send report
    send_email_report(results)

schedule.every().day.at("07:00").do(daily_analysis)

while True:
    schedule.run_pending()
    time.sleep(60)
```

## License

Internal use only - Proprietary

## Support

For questions or issues, contact the Data Analytics team.
