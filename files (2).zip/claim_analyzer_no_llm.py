"""
Claim Exclusion Analyzer - No LLM Version
Provides detailed tracing of why claims are excluded using only programmatic checks
"""

import snowflake.connector
import os
from typing import Dict, List, Optional, Tuple
import json
from datetime import datetime
from dateutil.relativedelta import relativedelta
from collections import defaultdict

class ClaimExclusionAnalyzer:
    
    # Define all exclusion rules from the SQL
    EXCLUSION_RULES = {
        'RULE_001': {
            'name': 'Excluded Markets',
            'description': 'Markets excluded from analysis (NM, MD-VANT, IL, SC-BLUE, CA)',
            'sql_ref': 'Line ~800: GRGR_CK in (10,12,15,20,22)',
            'business_impact': 'These markets are excluded from overpayment recovery processing',
            'check_type': 'simple'
        },
        'RULE_002': {
            'name': 'Unrecoverable Disallowance Codes',
            'description': 'Claims with specific disallowance codes that are unrecoverable',
            'sql_ref': 'exclude_disall_excd table',
            'business_impact': 'Claims with appeal or plan approval codes cannot be recovered',
            'check_type': 'table_lookup'
        },
        'RULE_003': {
            'name': 'HMS/Connolly Line Items',
            'description': 'Claims with EOB exclusion codes FA6 or FA8',
            'sql_ref': 'CLCL_EOB_EXCD_ID in (FA6, FA8)',
            'business_impact': 'HMS and Connolly vendor processed claims are excluded',
            'check_type': 'simple'
        },
        'RULE_004': {
            'name': 'Below Payment Threshold',
            'description': 'Claims below $25 (or $10 for specific markets)',
            'sql_ref': 'CHM0005: CLCL_TOT_PAYABLE thresholds',
            'business_impact': 'Small dollar claims not cost-effective to pursue',
            'check_type': 'complex'
        },
        'RULE_005': {
            'name': 'TN Plan Specific Exclusion',
            'description': 'TN market with specific plan IDs, bill types, and dates after 2024-06-30',
            'sql_ref': 'CHM0021b',
            'business_impact': 'TN contract changes effective July 1, 2024',
            'check_type': 'complex'
        },
        'RULE_006': {
            'name': 'Malicious Override Codes',
            'description': 'Claims with specific override codes (J00, J01, J02, JCN, etc.)',
            'sql_ref': 'CH0009C, CHM0003b',
            'business_impact': 'Claims with manual overrides cannot be auto-recovered',
            'check_type': 'complex'
        },
        'RULE_007': {
            'name': 'Expired Claims',
            'description': 'Claims that have exceeded their expiration date based on market rules',
            'sql_ref': 'CH0006B: Expiration date logic',
            'business_impact': 'Claims past statute of limitations or contract terms',
            'check_type': 'very_complex'
        },
        'RULE_008': {
            'name': 'DC Market Date Filter',
            'description': 'DC market claims with service dates before 2017-01-01',
            'sql_ref': 'CH0008D',
            'business_impact': 'Historical claims outside recovery window',
            'check_type': 'simple'
        },
        'RULE_009': {
            'name': 'Provider Type Exclusion',
            'description': 'TX market claims with specific provider specialties and revenue codes',
            'sql_ref': 'CH0009D',
            'business_impact': 'Specific provider arrangements preclude recovery',
            'check_type': 'complex'
        },
        'RULE_010': {
            'name': 'HIPAA Waiver IA',
            'description': 'Iowa market HIPAA FP waiver exclusions',
            'sql_ref': 'FHP_PMED_MEMBER_D and IAFPWV00 plan',
            'business_impact': 'Members with HIPAA waivers protected from recovery',
            'check_type': 'complex'
        },
        'RULE_011': {
            'name': 'Capitated Member Exclusion',
            'description': 'Claims for members with AGPCLMRCOUP Medicaid number',
            'sql_ref': 'MEME_MEDCD_NO = AGPCLMRCOUP',
            'business_impact': 'Capitated arrangements already reconciled',
            'check_type': 'simple'
        },
        'RULE_012': {
            'name': 'Hospital Claims Filter',
            'description': 'Claims starting with H in claim ID',
            'sql_ref': 'left(CLCL_ID,1) = H',
            'business_impact': 'Specific claim type excluded from process',
            'check_type': 'simple'
        },
        'RULE_013': {
            'name': 'Missing Overpayment Pair',
            'description': 'Reference or overpayment records without matching counterpart',
            'sql_ref': 'GROUP_ID matching logic',
            'business_impact': 'Cannot identify recovery without paired transactions',
            'check_type': 'very_complex'
        },
        'RULE_014': {
            'name': 'MO Market Expiration',
            'description': 'Missouri market claims that expired based on paid date',
            'sql_ref': 'CHM0021a: GRGR_CK = 234',
            'business_impact': 'Market-specific expiration rules',
            'check_type': 'complex'
        }
    }
    
    def __init__(self, snowflake_config: Dict):
        self.sf_conn = snowflake.connector.connect(**snowflake_config)
        self.cursor = self.sf_conn.cursor()
    
    def evaluate_rule_001(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check if claim is in excluded market."""
        grgr_ck = claim_data.get('GRGR_CK')
        excluded_markets = {
            10: 'NM',
            12: 'MD-VANT',
            15: 'VA',
            20: 'VA-VANT',
            22: 'Excluded market'
        }
        
        if grgr_ck in excluded_markets:
            details = {
                'grgr_ck': grgr_ck,
                'market_name': excluded_markets[grgr_ck],
                'reason': f"Market {excluded_markets[grgr_ck]} is excluded from overpayment processing"
            }
            return True, f"Claim belongs to excluded market: GRGR_CK={grgr_ck} ({excluded_markets[grgr_ck]})", details
        
        return False, "Passed: Not in excluded markets", {}
    
    def evaluate_rule_002(self, clcl_id: str, cdml_seq_no: int = None) -> Tuple[bool, str, Dict]:
        """Check for unrecoverable disallowance codes."""
        excluded_codes = {
            'FA5': 'line item HMS',
            'FA7': 'line item Connolly',
            'A01': 'ProcessedPerAppeal', 'A02': 'ProcessedPerAppeal', 'A03': 'ProcessedPerAppeal',
            'A04': 'ProcessedPerAppeal', 'A05': 'ProcessedPerAppeal', 'A06': 'ProcessedPerAppeal',
            'A07': 'ProcessedPerAppeal', 'A08': 'ProcessedPerAppeal', 'A09': 'ProcessedPerAppeal',
            'A10': 'ProcessedPerAppeal', 'A11': 'ProcessedPerAppeal', 'A12': 'ProcessedPerAppeal',
            'A13': 'ProcessedPerAppeal', 'A14': 'ProcessedPerAppeal', 'A15': 'ProcessedPerAppeal',
            'A16': 'ProcessedPerAppeal', 'A17': 'ProcessedPerAppeal', 'A18': 'ProcessedPerAppeal',
            'A19': 'ProcessedPerAppeal', 'A20': 'ProcessedPerAppeal', 'A21': 'ProcessedPerAppeal',
            'A22': 'ProcessedPerAppeal', 'A23': 'ProcessedPerAppeal', 'A24': 'ProcessedPerAppeal',
            'A25': 'ProcessedPerAppeal', 'A26': 'ProcessedPerAppeal', 'A27': 'AddlPaymentOnAppeal',
            'A28': 'AddlPaymentOnAppeal', 'A29': 'AddlPaymentOnAppeal', 'A30': 'AddlPaymentOnAppeal',
            'A31': 'AddlPaymentOnAppeal', 'A32': 'AddlPaymentOnAppeal', 'A33': 'AddlPaymentOnAppeal',
            'A34': 'AddlPaymentOnAppeal', 'A35': 'AddlPaymentOnAppeal', 'A36': 'AddlPaymentOnAppeal',
            'A37': 'AddlPaymentOnAppeal', 'A38': 'AddlPaymentOnAppeal', 'A39': 'AddlPaymentOnAppeal',
            'A40': 'AddlPaymentOnAppeal', 'A41': 'AddlPaymentOnAppeal', 'A42': 'AddlPaymentOnAppeal',
            'A43': 'AddlPaymentOnAppeal', 'A44': 'AddlPaymentOnAppeal', 'A45': 'AddlPaymentOnAppeal',
            'A46': 'AddlPaymentOnAppeal', 'A47': 'AddlPaymentOnAppeal', 'A48': 'AddlPaymentOnAppeal',
            'A49': 'AddlPaymentOnAppeal', 'A50': 'AddlPaymentOnAppeal', 'A51': 'AddlPaymentOnAppeal',
            'A52': 'AddlPaymentOnAppeal', 'A53': 'AppealDisallowed', 'A54': 'DenialUpheldOnAppeal',
            'A58': '72HourEligibility',
            'K01': 'PaidPerPlanApproval', 'K02': 'PaidPerPlanApproval', 'K03': 'PaidPerPlanApproval',
            'K04': 'PaidPerPlanApproval', 'K05': 'PaidPerPlanApproval', 'K06': 'PaidPerPlanApproval',
            'K07': 'PaidPerPlanApproval', 'K08': 'PaidPerPlanApproval', 'K09': 'PaidPerPlanApproval',
            'K10': 'PaidPerPlanApproval', 'K11': 'PaidPerPlanApproval', 'K12': 'PaidPerPlanApproval',
            'K13': 'PaidPerPlanApproval', 'K14': 'PaidPerPlanApproval', 'K15': 'PaidPerPlanApproval',
            'K16': 'PaidPerPlanApproval', 'K17': 'PaidPerPlanApproval', 'K18': 'PaidPerPlanApproval',
            'K19': 'PaidPerPlanApproval', 'K20': 'PaidPerPlanApproval', 'K21': 'PaidPerPlanApproval',
            'K22': 'PaidPerPlanApproval', 'K23': 'PaidPerPlanApproval', 'K24': 'PaidPerPlanApproval',
            'K25': 'PaidPerPlanApproval'
        }
        
        query = f"""
            SELECT CDML_DISALL_EXCD, CDML_SEQ_NO
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV
            WHERE CLCL_ID = '{clcl_id}'
        """
        if cdml_seq_no:
            query += f" AND CDML_SEQ_NO = {cdml_seq_no}"
        
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        for disallow_code, seq_no in results:
            if disallow_code in excluded_codes:
                details = {
                    'disallow_code': disallow_code,
                    'code_category': excluded_codes[disallow_code],
                    'line_number': seq_no,
                    'reason': f"Code indicates {excluded_codes[disallow_code]} - cannot be recovered"
                }
                return True, f"Found excluded disallowance code: {disallow_code} ({excluded_codes[disallow_code]}) on line {seq_no}", details
        
        return False, "Passed: No excluded disallowance codes found", {}
    
    def evaluate_rule_003(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check for HMS/Connolly exclusion codes."""
        eob_code = claim_data.get('CLCL_EOB_EXCD_ID')
        
        if eob_code in ('FA6', 'FA8'):
            vendor = 'HMS' if eob_code == 'FA6' else 'Connolly'
            details = {
                'eob_code': eob_code,
                'vendor': vendor,
                'reason': f"Claim processed by {vendor} - excluded from internal recovery"
            }
            return True, f"Claim has {vendor} exclusion code: {eob_code}", details
        
        return False, "Passed: No HMS/Connolly exclusion codes", {}
    
    def evaluate_rule_004(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check payment threshold."""
        grgr_ck = claim_data.get('GRGR_CK')
        tot_payable = claim_data.get('CLCL_TOT_PAYABLE', 0)
        record_type = claim_data.get('RECORD_TYPE', 'O')
        
        # Only applies to overpayment records
        if record_type == 'R':
            return False, "Passed: Reference record not subject to threshold check", {}
        
        if grgr_ck in (3, 34, 13, 31):
            threshold = 10
            market_type = "FL, KY, TN, VA-MM"
            if tot_payable < threshold:
                details = {
                    'grgr_ck': grgr_ck,
                    'total_payable': tot_payable,
                    'threshold': threshold,
                    'market_type': market_type,
                    'reason': f"Claims below ${threshold} not cost-effective to pursue for {market_type} markets"
                }
                return True, f"Below ${threshold} threshold for market {grgr_ck}: ${tot_payable:.2f}", details
        else:
            threshold = 25
            if tot_payable < threshold:
                details = {
                    'grgr_ck': grgr_ck,
                    'total_payable': tot_payable,
                    'threshold': threshold,
                    'reason': f"Claims below ${threshold} not cost-effective to pursue"
                }
                return True, f"Below ${threshold} threshold: ${tot_payable:.2f}", details
        
        return False, f"Passed: Total payable ${tot_payable:.2f} meets threshold", {}
    
    def evaluate_rule_005(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check TN market specific exclusion (CHM0021b)."""
        grgr_ck = claim_data.get('GRGR_CK')
        cscs_id = claim_data.get('CSCS_ID', '')
        cdml_from_dt = claim_data.get('CDML_FROM_DT')
        clhp_fac_type = claim_data.get('CLHP_FAC_TYPE', '')
        clhp_bill_class = claim_data.get('CLHP_BILL_CLASS', '')
        
        if grgr_ck != 13:
            return False, "Passed: Not TN market", {}
        
        tn_plans = ['PL10','PL11','PL12','PL95','PL96','PL97','CD04','CD05','CD06','CD07','CD08','CD09']
        if cscs_id not in tn_plans:
            return False, "Passed: Not in excluded TN plan list", {}
        
        bill_type = f"{clhp_fac_type}{clhp_bill_class}"
        if bill_type not in ['066', '089']:
            return False, f"Passed: Bill type {bill_type} not in exclusion list", {}
        
        cutoff_date = datetime(2024, 6, 30).date()
        if cdml_from_dt and cdml_from_dt > cutoff_date:
            details = {
                'grgr_ck': grgr_ck,
                'market': 'Tennessee',
                'cscs_id': cscs_id,
                'bill_type': bill_type,
                'service_date': str(cdml_from_dt),
                'cutoff_date': '2024-06-30',
                'reason': 'TN contract changes effective July 1, 2024 exclude these claims from recovery'
            }
            return True, f"EXCLUDED: TN market ({cscs_id}), bill type {bill_type}, date {cdml_from_dt} > 2024-06-30", details
        
        return False, "Passed: Service date before 2024-06-30 cutoff", {}
    
    def evaluate_rule_006(self, clcl_id: str) -> Tuple[bool, str, Dict]:
        """Check for malicious override codes."""
        excluded_override_codes = {
            'J00': 'Manual override code', 
            'J01': 'Manual override code', 
            'J02': 'Manual override code', 
            'JCN': 'Manual override code',
            'YHK': 'Manual override code', 
            'EAM': 'Manual override code', 
            'G03': 'Manual override code', 
            'G97': 'Manual override code',
            'FD3': 'Manual override code', 
            'FD4': 'Manual override code', 
            'FD5': 'Manual override code'
        }
        
        found_codes = []
        
        # Check CDML
        query = f"""
            SELECT CDML_DISALL_EXCD 
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV
            WHERE CLCL_ID = '{clcl_id}'
              AND CDML_CUR_STS = '02'
              AND CDML_PR_PYMT_AMT > 0
        """
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        for (code,) in results:
            if code in excluded_override_codes:
                found_codes.append({'source': 'CDML', 'code': code, 'description': excluded_override_codes[code]})
        
        # Check CDOR
        query = f"""
            SELECT EXCD_ID 
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDOR_LI_OVR_CMPCT
            WHERE CLCL_ID = '{clcl_id}'
        """
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        for (code,) in results:
            if code in excluded_override_codes:
                found_codes.append({'source': 'CDOR (Line Override)', 'code': code, 'description': excluded_override_codes[code]})
        
        # Check CLOR
        query = f"""
            SELECT EXCD_ID 
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLOR_CL_OVR_CMPCT
            WHERE CLCL_ID = '{clcl_id}'
        """
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        for (code,) in results:
            if code in excluded_override_codes:
                found_codes.append({'source': 'CLOR (Claim Override)', 'code': code, 'description': excluded_override_codes[code]})
        
        # Check ADJ_CLM_RSN
        query = f"""
            SELECT ADJ_RSN_CD 
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.ADJ_CLM_RSN_CMPCT
            WHERE CLCL_ID = '{clcl_id}'
        """
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        for (code,) in results:
            if code in excluded_override_codes:
                found_codes.append({'source': 'ADJ (Adjustment Reason)', 'code': code, 'description': excluded_override_codes[code]})
        
        if found_codes:
            details = {
                'override_codes': found_codes,
                'reason': 'Claims with manual overrides cannot be automatically recovered'
            }
            msg = f"Found {len(found_codes)} excluded override code(s): " + ", ".join([f"{c['code']} in {c['source']}" for c in found_codes])
            return True, msg, details
        
        return False, "Passed: No excluded override codes found", {}
    
    def evaluate_rule_007(self, clcl_id: str, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check if claim has expired based on market-specific expiration rules."""
        grgr_ck = claim_data.get('GRGR_CK')
        clcl_paid_dt = claim_data.get('CLCL_PAID_DT')
        clcl_recd_dt = claim_data.get('CLCL_RECD_DT')
        cdml_from_dt = claim_data.get('CDML_FROM_DT')
        clhp_fac_type = claim_data.get('CLHP_FAC_TYPE')
        ipcd_id = claim_data.get('IPCD_ID', '')
        record_type = claim_data.get('RECORD_TYPE', 'O')
        
        if record_type == 'R':
            return False, "Passed: Reference record not subject to expiration check", {}
        
        # Get expiration rules for this market
        query = f"""
            SELECT mer.GRGR_CK, mer.EXPIRATION_ID, mer.MONTHS_TO_EXPIRE, mer.EXPTYPE,
                   cer.EXPIRATION_DESC
            FROM (
                SELECT GRGR_CK, EXPIRATION_ID, 
                       NULL as MONTHS_TO_EXPIRE, NULL as EXPTYPE
                FROM (VALUES
                    (36,129),(39,161),(51,131),(53,133),(42,135),(3,28),(3,6),(25,27),(16,27),
                    (24,137),(49,137),(7,5973),(54,3888),(47,139),(67,3907),(67,3908),(6,4110),
                    (30,4083),(91,27),(92,27),(34,34),(48,141),(28,4357),(5,13),(12,27),(44,143),
                    (45,145),(43,147),(1,17),(26,27),(19,27),(9,165),(21,3643),(11,21),(40,162),
                    (18,149),(41,149),(46,151),(13,24),(17,27),(52,163),(4,5),(27,153),(8,153),
                    (23,5),(37,164),(32,155),(31,25),(29,26),(33,157),(38,130),(50,159),(88,5),
                    (89,21),(90,4356),(55,3915),(56,3916),(57,3904),(58,3906),(59,3912),(60,3911),
                    (61,3902),(62,3913),(63,3903),(64,3917),(65,3905),(66,3910),(68,3914),(93,26),
                    (102,4370),(104,4330),(99,4329),(144,27),(133,27),(106,27),(107,27),(119,27),
                    (120,27),(125,27),(126,27),(140,27),(117,27),(118,27),(105,27),(108,27),
                    (109,27),(110,27),(111,27),(112,27),(113,27),(115,27),(116,27),(121,27),
                    (122,27),(123,27),(124,27),(127,27),(128,27),(129,27),(131,27),(132,27),
                    (135,27),(136,27),(138,27),(139,27),(142,27),(143,27),(137,27),(212,27),
                    (345,22),(234,4354),(236,4355),(242,27),(168,4364),(243,27),(103,4330),
                    (95,4225),(98,3919)
                ) as t(GRGR_CK, EXPIRATION_ID)
            ) mer
            LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CCU_EXPIRATION_RULE_CMPCT cer 
                ON mer.EXPIRATION_ID = cer.EXPIRATION_ID
            WHERE mer.GRGR_CK = {grgr_ck}
        """
        
        self.cursor.execute(query)
        exp_rules = self.cursor.fetchall()
        
        if not exp_rules:
            return False, "Passed: No expiration rules defined for this market", {}
        
        # Determine which expiration rule applies
        applicable_rule = None
        for rule in exp_rules:
            rule_grgr_ck, expiration_id, months_to_expire, exptype, exp_desc = rule
            
            # Special logic for FL market (GRGR_CK = 3)
            if grgr_ck == 3:
                if clhp_fac_type is None and ipcd_id[:5] != 'T2030' and expiration_id == 6:
                    applicable_rule = rule
                    break
                elif (clhp_fac_type is not None or ipcd_id[:5] == 'T2030') and expiration_id == 28:
                    applicable_rule = rule
                    break
            # Special logic for VA MED-SUPP (GRGR_CK = 67)
            elif grgr_ck == 67:
                if clhp_fac_type is None and expiration_id == 3907:
                    applicable_rule = rule
                    break
                elif clhp_fac_type is not None and expiration_id == 3908:
                    applicable_rule = rule
                    break
            else:
                applicable_rule = rule
                break
        
        if not applicable_rule:
            return False, "Passed: No applicable expiration rule found", {}
        
        _, expiration_id, months_to_expire, exptype, exp_desc = applicable_rule
        
        # Get actual expiration details from CCU_EXPIRATION_RULE_CMPCT
        query = f"""
            SELECT MONTHS_TO_EXPIRE, MONTHSTOEXPIRE_SQL, EXPIRATION_DESC
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CCU_EXPIRATION_RULE_CMPCT
            WHERE EXPIRATION_ID = {expiration_id}
              AND MONTHS_TO_EXPIRE IS NOT NULL
        """
        
        self.cursor.execute(query)
        exp_detail = self.cursor.fetchone()
        
        if not exp_detail:
            return False, "Passed: No expiration detail found", {}
        
        months_to_expire, months_sql, exp_desc = exp_detail
        
        # Determine expiration type from SQL
        if 'PAID' in str(months_sql).upper():
            exptype = 'PAID'
            reference_date = clcl_paid_dt
        elif 'SVC' in str(months_sql).upper():
            exptype = 'DOS'
            reference_date = cdml_from_dt
        elif 'RECD' in str(months_sql).upper():
            exptype = 'RECD'
            reference_date = clcl_recd_dt
        else:
            return False, "Passed: Unknown expiration type", {}
        
        # Calculate expiration date (months are negative, so we add them)
        from dateutil.relativedelta import relativedelta
        current_date = datetime.now().date()
        exp_dt = current_date + relativedelta(months=months_to_expire)
        
        # Get original claim paid/received date
        query = f"""
            SELECT CLCL_PAID_DT, CLCL_RECD_DT, CLCL_LOW_SVC_DT
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLCL_CLAIM_CMPCT_ACTV
            WHERE CLCL_ID = CONCAT(LEFT('{clcl_id}', 10), '00')
        """
        
        self.cursor.execute(query)
        orig_claim = self.cursor.fetchone()
        
        if not orig_claim:
            return False, "Passed: Original claim not found", {}
        
        orig_paid_dt, orig_recd_dt, orig_svc_dt = orig_claim
        
        # Check if expired based on type
        is_expired = False
        comparison_date = None
        
        if exptype == 'PAID':
            # Special handling for NJ (GRGR_CK = 1)
            if grgr_ck == 1:
                # Check if original claim has positive payment
                if orig_paid_dt and exp_dt >= orig_paid_dt:
                    is_expired = True
                    comparison_date = orig_paid_dt
            # Special handling for MO (GRGR_CK = 234)
            elif grgr_ck == 234:
                if clcl_paid_dt and exp_dt >= clcl_paid_dt:
                    is_expired = True
                    comparison_date = clcl_paid_dt
            # All other markets
            elif orig_paid_dt and exp_dt >= orig_paid_dt:
                is_expired = True
                comparison_date = orig_paid_dt
        elif exptype == 'RECD':
            if orig_recd_dt and exp_dt >= orig_recd_dt:
                is_expired = True
                comparison_date = orig_recd_dt
        elif exptype == 'DOS':
            if orig_svc_dt and exp_dt >= orig_svc_dt:
                is_expired = True
                comparison_date = orig_svc_dt
        
        if is_expired:
            details = {
                'grgr_ck': grgr_ck,
                'expiration_id': expiration_id,
                'expiration_desc': exp_desc,
                'months_to_expire': months_to_expire,
                'expiration_type': exptype,
                'expiration_date': str(exp_dt),
                'comparison_date': str(comparison_date),
                'reference_date_type': exptype,
                'reason': f"Claim expired: {exptype} date {comparison_date} is before expiration date {exp_dt}"
            }
            return True, f"Claim expired on {exp_dt} (based on {exptype} date {comparison_date})", details
        
        return False, f"Passed: Not expired (expires on {exp_dt})", {}
    
    def evaluate_rule_008(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check DC market date filter."""
        grgr_ck = claim_data.get('GRGR_CK')
        cdml_from_dt = claim_data.get('CDML_FROM_DT')
        record_type = claim_data.get('RECORD_TYPE', 'O')
        
        if record_type == 'R':
            return False, "Passed: Reference record not subject to date filter", {}
        
        if grgr_ck == 6:
            cutoff_date = datetime(2017, 1, 1).date()
            if cdml_from_dt and cdml_from_dt < cutoff_date:
                details = {
                    'grgr_ck': grgr_ck,
                    'market': 'DC',
                    'service_date': str(cdml_from_dt),
                    'cutoff_date': '2017-01-01',
                    'reason': 'DC market claims before 2017 are outside recovery window'
                }
                return True, f"DC market claim with service date {cdml_from_dt} before 2017-01-01", details
        
        return False, "Passed: Not DC market or date within range", {}
    
    
    def evaluate_rule_009(self, clcl_id: str, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check TX market provider type exclusion (CH0009D)."""
        grgr_ck = claim_data.get('GRGR_CK')
        record_type = claim_data.get('RECORD_TYPE', 'O')
        
        # Only applies to TX markets and overpayment records
        if grgr_ck not in (4, 23, 27, 88, 52):
            return False, "Passed: Not a TX market", {}
        
        if record_type == 'R':
            return False, "Passed: Reference record not subject to provider exclusion", {}
        
        # Get provider specialty and type
        query = f"""
            SELECT 
                pr.PRCF_MCTR_SPEC,
                pr.PRPR_MCTR_TYPE,
                cdml.RCRC_ID,
                cdml.CDML_SEQ_NO,
                cdml.CDML_PR_PYMT_AMT
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV cdml
            INNER JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_PRPR_PROV_CMPCT_ACTV pr 
                ON cdml.PRPR_ID = pr.PRPR_ID
            WHERE cdml.CLCL_ID = '{clcl_id}'
        """
        
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        
        excluded_specs = ['S098', 'S173']
        excluded_rcrcs = ['0100', '0101', '0230', '0410', '0430', '0431', '0433']
        
        for prcf_spec, prpr_type, rcrc_id, seq_no, pymt_amt in results:
            # Check if provider has excluded specialty or type
            if (prcf_spec in excluded_specs or prpr_type in excluded_specs):
                # Check if revenue code is in excluded list
                if rcrc_id in excluded_rcrcs:
                    # Check if there's no line 1 with revenue code 022
                    query_line1 = f"""
                        SELECT CDML_PR_PYMT_AMT
                        FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV
                        WHERE CLCL_ID = '{clcl_id}'
                          AND CDML_SEQ_NO = 1
                          AND RCRC_ID = '022'
                          AND CDML_PR_PYMT_AMT > 0
                    """
                    
                    self.cursor.execute(query_line1)
                    line1_result = self.cursor.fetchone()
                    
                    if not line1_result:
                        details = {
                            'grgr_ck': grgr_ck,
                            'market': 'Texas',
                            'provider_specialty': prcf_spec if prcf_spec in excluded_specs else prpr_type,
                            'revenue_code': rcrc_id,
                            'line_seq_no': seq_no,
                            'reason': 'TX market excludes specific provider specialties (S098, S173) with certain revenue codes unless line 1 has revenue code 022'
                        }
                        return True, f"TX market provider exclusion: specialty {prcf_spec or prpr_type} with revenue code {rcrc_id}, no line 1 with RC 022", details
        
        return False, "Passed: No TX provider type exclusions apply", {}
    
    def evaluate_rule_010(self, clcl_id: str, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check Iowa HIPAA FP waiver exclusion."""
        grgr_ck = claim_data.get('GRGR_CK')
        cspi_id = claim_data.get('CSPI_ID', '')
        sbsb_ck = claim_data.get('SBSB_CK')
        record_type = claim_data.get('RECORD_TYPE', 'O')
        
        if record_type == 'R':
            return False, "Passed: Reference record not subject to HIPAA waiver check", {}
        
        if grgr_ck != 54:
            return False, "Passed: Not Iowa market", {}
        
        # Check if plan is IAFPWV00
        if cspi_id == 'IAFPWV00':
            details = {
                'grgr_ck': grgr_ck,
                'market': 'Iowa',
                'plan_id': cspi_id,
                'reason': 'Iowa HIPAA FP waiver plan members are protected from recovery'
            }
            return True, f"Iowa HIPAA FP waiver plan exclusion: {cspi_id}", details
        
        # Check FHP_PMED_MEMBER_D and FHP_PMCC_COMM_X tables
        if not sbsb_ck:
            return False, "Passed: No subscriber key to check HIPAA waiver", {}
        
        # Get SBSB_ID and GRGR_ID for member lookup
        query = f"""
            SELECT sbsb.SBSB_ID, grgr.GRGR_ID
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_SBSB_SUBSC_CMPCT_ACTV sbsb
            INNER JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_GRGR_GROUP_CMPCT_ACTV grgr 
                ON sbsb.GRGR_CK = grgr.GRGR_CK
            WHERE sbsb.SBSB_CK = {sbsb_ck}
              AND grgr.GRGR_CK = 54
        """
        
        self.cursor.execute(query)
        sbsb_result = self.cursor.fetchone()
        
        if not sbsb_result:
            return False, "Passed: No subscriber info found", {}
        
        sbsb_id, grgr_id = sbsb_result
        
        # Check if member has HIPAA waiver
        query = f"""
            SELECT pmed.PMED_CKE
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.FHP_PMED_MEMBER_D_CMPCT_ACTV pmed
            INNER JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.FHP_PMCC_COMM_X_CMPCT_ACTV pmcc 
                ON pmed.PMED_CKE = pmcc.PMED_CKE
            WHERE pmed.PMED_ID LIKE '{grgr_id}%{sbsb_id}%'
            LIMIT 1
        """
        
        self.cursor.execute(query)
        waiver_result = self.cursor.fetchone()
        
        if waiver_result:
            details = {
                'grgr_ck': grgr_ck,
                'market': 'Iowa',
                'sbsb_id': sbsb_id,
                'reason': 'Member has HIPAA FP waiver - protected from recovery'
            }
            return True, "Iowa HIPAA FP waiver member found in FHP tables", details
        
        return False, "Passed: No Iowa HIPAA waiver found", {}
    
    
    def evaluate_rule_013(self, clcl_id: str, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check if claim has matching reference/overpayment pair."""
        
        # First, check if this claim is part of the initial overpayment selection
        # (paid in the report period with specific criteria)
        query = f"""
            SELECT dt.GROUP_ID, dt.RECORD_TYPE
            FROM (
                SELECT 
                    clcl.GRGR_CK, 
                    clcl.MEME_CK, 
                    clcl.CLCL_RECD_DT, 
                    clcl.CLCL_ID, 
                    cdml.CDML_SEQ_NO, 
                    cdml.CDML_FROM_DT, 
                    clcl.CLCL_PAID_DT,
                    DENSE_RANK() OVER (
                        ORDER BY clcl.GRGR_CK, clcl.MEME_CK, cdml.CDML_FROM_DT
                    ) AS GROUP_ID,
                    DENSE_RANK() OVER (
                        PARTITION BY DENSE_RANK() OVER (
                            ORDER BY clcl.GRGR_CK, clcl.MEME_CK, cdml.CDML_FROM_DT
                        )
                        ORDER BY clcl.CLCL_RECD_DT, clcl.CLCL_ID, cdml.CDML_SEQ_NO
                    ) AS GROUP_ROW_NUMBER
                FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLCL_CLAIM_CMPCT_ACTV clcl
                INNER JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV cdml 
                    ON clcl.CLCL_ID = cdml.CLCL_ID
                WHERE clcl.GRGR_CK = 1 
                  AND clcl.CLCL_CUR_STS = '02'
                  AND cdml.CDML_CUR_STS = '02'
                  AND cdml.IPCD_ID LIKE 'S5102%'
                  AND cdml.CDML_PR_PYMT_AMT > 0
                  AND EXISTS (
                      SELECT 1 
                      FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLCL_CLAIM_CMPCT_ACTV c2
                      WHERE c2.GRGR_CK = clcl.GRGR_CK
                        AND c2.MEME_CK = clcl.MEME_CK
                        AND c2.CLCL_ID = clcl.CLCL_ID
                  )
            ) dt
            WHERE dt.CLCL_ID = '{clcl_id}'
        """
        
        self.cursor.execute(query)
        group_result = self.cursor.fetchone()
        
        if not group_result:
            return False, "Passed: Claim not in overpayment pairing logic", {}
        
        group_id, record_type = group_result
        
        # Assign record type based on order
        if record_type == 'R':
            # This is a reference record - check for overpayment record
            query_pair = f"""
                SELECT COUNT(*) 
                FROM (
                    SELECT clcl.CLCL_ID
                    FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLCL_CLAIM_CMPCT_ACTV clcl
                    INNER JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV cdml 
                        ON clcl.CLCL_ID = cdml.CLCL_ID
                    WHERE clcl.GRGR_CK = 1 
                      AND clcl.CLCL_CUR_STS = '02'
                      AND cdml.CDML_CUR_STS = '02'
                      AND cdml.IPCD_ID LIKE 'S5102%'
                      AND cdml.CDML_PR_PYMT_AMT > 0
                      AND DENSE_RANK() OVER (
                          ORDER BY clcl.GRGR_CK, clcl.MEME_CK, cdml.CDML_FROM_DT
                      ) = {group_id}
                      AND DENSE_RANK() OVER (
                          PARTITION BY DENSE_RANK() OVER (
                              ORDER BY clcl.GRGR_CK, clcl.MEME_CK, cdml.CDML_FROM_DT
                          )
                          ORDER BY clcl.CLCL_RECD_DT, clcl.CLCL_ID, cdml.CDML_SEQ_NO
                      ) > 1
                ) pairs
            """
            
            self.cursor.execute(query_pair)
            ovp_count = self.cursor.fetchone()[0]
            
            if ovp_count == 0:
                details = {
                    'group_id': group_id,
                    'record_type': 'Reference',
                    'missing_type': 'Overpayment',
                    'reason': 'Reference record exists but no matching overpayment record found - cannot identify recovery amount'
                }
                return True, f"Missing overpayment pair for reference record (GROUP_ID: {group_id})", details
        
        else:
            # This is an overpayment record - check for reference record
            query_pair = f"""
                SELECT COUNT(*) 
                FROM (
                    SELECT clcl.CLCL_ID
                    FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLCL_CLAIM_CMPCT_ACTV clcl
                    INNER JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV cdml 
                        ON clcl.CLCL_ID = cdml.CLCL_ID
                    WHERE clcl.GRGR_CK = 1 
                      AND clcl.CLCL_CUR_STS = '02'
                      AND cdml.CDML_CUR_STS = '02'
                      AND cdml.IPCD_ID LIKE 'S5102%'
                      AND cdml.CDML_PR_PYMT_AMT > 0
                      AND DENSE_RANK() OVER (
                          ORDER BY clcl.GRGR_CK, clcl.MEME_CK, cdml.CDML_FROM_DT
                      ) = {group_id}
                      AND DENSE_RANK() OVER (
                          PARTITION BY DENSE_RANK() OVER (
                              ORDER BY clcl.GRGR_CK, clcl.MEME_CK, cdml.CDML_FROM_DT
                          )
                          ORDER BY clcl.CLCL_RECD_DT, clcl.CLCL_ID, cdml.CDML_SEQ_NO
                      ) = 1
                ) pairs
            """
            
            self.cursor.execute(query_pair)
            ref_count = self.cursor.fetchone()[0]
            
            if ref_count == 0:
                details = {
                    'group_id': group_id,
                    'record_type': 'Overpayment',
                    'missing_type': 'Reference',
                    'reason': 'Overpayment record exists but no matching reference record found - cannot calculate recovery'
                }
                return True, f"Missing reference pair for overpayment record (GROUP_ID: {group_id})", details
        
        return False, "Passed: Has matching reference/overpayment pair", {}
    
    def evaluate_rule_014(self, clcl_id: str, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check Missouri market expiration (CHM0021a)."""
        grgr_ck = claim_data.get('GRGR_CK')
        clcl_paid_dt = claim_data.get('CLCL_PAID_DT')
        record_type = claim_data.get('RECORD_TYPE', 'O')
        
        if record_type == 'R':
            return False, "Passed: Reference record not subject to MO expiration", {}
        
        if grgr_ck != 234:
            return False, "Passed: Not Missouri market", {}
        
        # Get MO market expiration rule (EXPIRATION_ID = 4354)
        query = f"""
            SELECT MONTHS_TO_EXPIRE, EXPIRATION_DESC
            FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CCU_EXPIRATION_RULE_CMPCT
            WHERE EXPIRATION_ID = 4354
              AND MONTHS_TO_EXPIRE IS NOT NULL
        """
        
        self.cursor.execute(query)
        exp_rule = self.cursor.fetchone()
        
        if not exp_rule:
            return False, "Passed: No MO expiration rule found", {}
        
        months_to_expire, exp_desc = exp_rule
        
        # Calculate expiration date
        from dateutil.relativedelta import relativedelta
        current_date = datetime.now().date()
        exp_dt = current_date + relativedelta(months=months_to_expire)
        
        # For MO, check against paid date
        if clcl_paid_dt and exp_dt >= clcl_paid_dt:
            details = {
                'grgr_ck': grgr_ck,
                'market': 'Missouri',
                'paid_date': str(clcl_paid_dt),
                'expiration_date': str(exp_dt),
                'months_to_expire': months_to_expire,
                'expiration_desc': exp_desc,
                'reason': 'MO market claims expired based on paid date criteria'
            }
            return True, f"MO market expired: paid date {clcl_paid_dt} before expiration {exp_dt}", details
        
        return False, f"Passed: MO claim not expired (expires on {exp_dt})", {}
    
    def evaluate_rule_011(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check for capitated member exclusion."""
        medcd_no = claim_data.get('MEME_MEDCD_NO', '')
        
        if medcd_no == 'AGPCLMRCOUP':
            details = {
                'medicaid_number': 'AGPCLMRCOUP',
                'reason': 'Member has capitated arrangement - claims already reconciled'
            }
            return True, "Member has capitated exclusion code (AGPCLMRCOUP)", details
        
        return False, "Passed: Not a capitated member", {}
    
    def evaluate_rule_012(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
        """Check hospital claims filter."""
        clcl_id = claim_data.get('CLCL_ID', '')
        
        if clcl_id.startswith('H'):
            details = {
                'clcl_id': clcl_id,
                'reason': 'Hospital claim type excluded from this process'
            }
            return True, f"Claim ID starts with 'H': {clcl_id}", details
        
        return False, "Passed: Not a hospital claim", {}
    
    def get_claim_data(self, clcl_id: str, cdml_seq_no: Optional[int] = None) -> List[Dict]:
        """Fetch comprehensive claim data from Snowflake tables."""
        
        query = f"""
        SELECT 
            clcl.CLCL_ID,
            clcl.GRGR_CK,
            clcl.SBSB_CK,
            clcl.CLCL_CUR_STS,
            clcl.CLCL_PAID_DT,
            clcl.CLCL_RECD_DT,
            clcl.CSCS_ID,
            clcl.CLCL_TOT_PAYABLE,
            clcl.CLCL_EOB_EXCD_ID,
            clcl.PDPD_ID,
            clcl.CSPI_ID,
            cdml.CDML_SEQ_NO,
            cdml.CDML_DISALL_EXCD,
            cdml.CDML_FROM_DT,
            cdml.CDML_TO_DT,
            cdml.CDML_PR_PYMT_AMT,
            cdml.IPCD_ID,
            cdml.RCRC_ID,
            cdml.MEME_CK,
            cdml.PRPR_ID,
            clhp.CLHP_FAC_TYPE,
            clhp.CLHP_BILL_CLASS,
            pdpd.LOBD_ID,
            P01_PROTEGRITY.SCRTY_ACS_CNTRL.ANTM_MBR_IDENTIFIERS_DETOK(meme.MEME_MEDCD_NO) as MEME_MEDCD_NO
        FROM P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLCL_CLAIM_CMPCT_ACTV clcl
        LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CDML_CL_LINE_CMPCT_ACTV cdml 
            ON clcl.CLCL_ID = cdml.CLCL_ID
        LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_CLHP_HOSP_CMPCT_ACTV clhp 
            ON clcl.CLCL_ID = clhp.CLCL_ID
        LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_PDPD_PRODUCT_CMPCT_ACTV pdpd 
            ON clcl.PDPD_ID = pdpd.PDPD_ID
        LEFT JOIN P01_EDL.EDL_RAWZ_CMPCT_ALLPHI.CMC_MEME_MEMBER_CMPCT_ACTV meme 
            ON cdml.MEME_CK = meme.MEME_CK
        WHERE clcl.CLCL_ID = '{clcl_id}'
        """
        
        if cdml_seq_no:
            query += f" AND cdml.CDML_SEQ_NO = {cdml_seq_no}"
        
        self.cursor.execute(query)
        columns = [col[0] for col in self.cursor.description]
        results = self.cursor.fetchall()
        
        if not results:
            return []
        
        # Convert to list of dicts
        claim_data = []
        for row in results:
            claim_data.append(dict(zip(columns, row)))
        
        return claim_data
    
    def run_all_checks(self, clcl_id: str, cdml_seq_no: Optional[int] = None) -> Dict:
        """Run all exclusion checks on a claim."""
        
        # Get claim data
        claim_data_list = self.get_claim_data(clcl_id, cdml_seq_no)
        
        if not claim_data_list:
            return {'error': f'Claim {clcl_id} not found'}
        
        # Use first row for claim-level checks (usually all rows have same claim-level data)
        claim_data = claim_data_list[0]
        
        check_results = {
            'claim_id': clcl_id,
            'cdml_seq_no': cdml_seq_no,
            'claim_data': claim_data,
            'exclusion_reasons': [],
            'passed_rules': [],
            'verdict': 'INCLUDED',
            'line_items_checked': len(claim_data_list)
        }
        
        # Run each rule
        rules_to_check = [
            ('RULE_001', lambda: self.evaluate_rule_001(claim_data)),
            ('RULE_002', lambda: self.evaluate_rule_002(clcl_id, cdml_seq_no)),
            ('RULE_003', lambda: self.evaluate_rule_003(claim_data)),
            ('RULE_004', lambda: self.evaluate_rule_004(claim_data)),
            ('RULE_005', lambda: self.evaluate_rule_005(claim_data)),
            ('RULE_006', lambda: self.evaluate_rule_006(clcl_id)),
            ('RULE_007', lambda: self.evaluate_rule_007(clcl_id, claim_data)),
            ('RULE_008', lambda: self.evaluate_rule_008(claim_data)),
            ('RULE_009', lambda: self.evaluate_rule_009(clcl_id, claim_data)),
            ('RULE_010', lambda: self.evaluate_rule_010(clcl_id, claim_data)),
            ('RULE_011', lambda: self.evaluate_rule_011(claim_data)),
            ('RULE_012', lambda: self.evaluate_rule_012(claim_data)),
            ('RULE_013', lambda: self.evaluate_rule_013(clcl_id, claim_data)),
            ('RULE_014', lambda: self.evaluate_rule_014(clcl_id, claim_data)),
        ]
        
        for rule_id, check_func in rules_to_check:
            try:
                excluded, msg, details = check_func()
                if excluded:
                    rule_info = self.EXCLUSION_RULES[rule_id]
                    check_results['exclusion_reasons'].append({
                        'rule_id': rule_id,
                        'rule_name': rule_info['name'],
                        'message': msg,
                        'details': details,
                        'sql_reference': rule_info['sql_ref'],
                        'business_impact': rule_info['business_impact']
                    })
                    check_results['verdict'] = 'EXCLUDED'
                else:
                    check_results['passed_rules'].append({
                        'rule_id': rule_id,
                        'rule_name': self.EXCLUSION_RULES[rule_id]['name'],
                        'message': msg
                    })
            except Exception as e:
                check_results['passed_rules'].append({
                    'rule_id': rule_id,
                    'rule_name': self.EXCLUSION_RULES[rule_id]['name'],
                    'message': f"Error checking rule: {str(e)}"
                })
        
        return check_results
    
    def format_analysis_report(self, check_results: Dict) -> str:
        """Format the analysis results into a readable report."""
        
        if 'error' in check_results:
            return check_results['error']
        
        report = []
        report.append("=" * 80)
        report.append("CLAIM EXCLUSION ANALYSIS REPORT")
        report.append("=" * 80)
        report.append("")
        
        # Claim Info
        report.append("CLAIM INFORMATION:")
        report.append(f"  Claim ID: {check_results['claim_id']}")
        if check_results.get('cdml_seq_no'):
            report.append(f"  Line Sequence: {check_results['cdml_seq_no']}")
        report.append(f"  Line Items Checked: {check_results['line_items_checked']}")
        report.append("")
        
        # Key Claim Data
        claim_data = check_results['claim_data']
        report.append("KEY CLAIM DATA:")
        report.append(f"  Market (GRGR_CK): {claim_data.get('GRGR_CK')}")
        report.append(f"  Plan ID (CSCS_ID): {claim_data.get('CSCS_ID')}")
        report.append(f"  Total Payable: ${claim_data.get('CLCL_TOT_PAYABLE', 0):.2f}")
        report.append(f"  Service Date: {claim_data.get('CDML_FROM_DT')}")
        report.append(f"  Paid Date: {claim_data.get('CLCL_PAID_DT')}")
        if claim_data.get('CLHP_FAC_TYPE') or claim_data.get('CLHP_BILL_CLASS'):
            report.append(f"  Bill Type: {claim_data.get('CLHP_FAC_TYPE', '')}{claim_data.get('CLHP_BILL_CLASS', '')}")
        report.append("")
        
        # Verdict
        report.append("=" * 80)
        report.append(f"VERDICT: {check_results['verdict']}")
        report.append("=" * 80)
        report.append("")
        
        # Exclusion Reasons
        if check_results['exclusion_reasons']:
            report.append("EXCLUSION REASONS:")
            report.append("")
            
            for i, reason in enumerate(check_results['exclusion_reasons'], 1):
                report.append(f"{i}. [{reason['rule_id']}] {reason['rule_name']}")
                report.append(f"   Message: {reason['message']}")
                report.append(f"   SQL Reference: {reason['sql_reference']}")
                report.append(f"   Business Impact: {reason['business_impact']}")
                
                if reason['details']:
                    report.append("   Details:")
                    for key, value in reason['details'].items():
                        if key != 'reason':
                            report.append(f"     - {key}: {value}")
                    if 'reason' in reason['details']:
                        report.append(f"   Explanation: {reason['details']['reason']}")
                report.append("")
        else:
            report.append("✓ No exclusion reasons found - claim would be INCLUDED in final output")
            report.append("")
        
        # Rules Passed
        report.append(f"RULES PASSED: {len(check_results['passed_rules'])}")
        report.append("")
        for rule in check_results['passed_rules']:
            report.append(f"  ✓ [{rule['rule_id']}] {rule['rule_name']}")
            report.append(f"    {rule['message']}")
        
        report.append("")
        report.append("=" * 80)
        report.append("END OF REPORT")
        report.append("=" * 80)
        
        return "\n".join(report)
    
    def analyze_claim(self, clcl_id: str, cdml_seq_no: Optional[int] = None, 
                     output_format: str = 'report') -> str:
        """
        Full analysis of a claim.
        
        Args:
            clcl_id: Claim ID to analyze
            cdml_seq_no: Optional line sequence number
            output_format: 'report' for formatted report, 'json' for JSON output
        
        Returns:
            Formatted analysis string
        """
        
        check_results = self.run_all_checks(clcl_id, cdml_seq_no)
        
        if output_format == 'json':
            return json.dumps(check_results, indent=2, default=str)
        else:
            return self.format_analysis_report(check_results)
    
    def analyze_multiple_claims(self, claim_ids: List[str]) -> Dict[str, Dict]:
        """Analyze multiple claims and return summary statistics."""
        
        results = {}
        summary = {
            'total_claims': len(claim_ids),
            'excluded_claims': 0,
            'included_claims': 0,
            'exclusion_by_rule': defaultdict(int),
            'errors': 0
        }
        
        for clcl_id in claim_ids:
            check_results = self.run_all_checks(clcl_id)
            results[clcl_id] = check_results
            
            if 'error' in check_results:
                summary['errors'] += 1
            elif check_results['verdict'] == 'EXCLUDED':
                summary['excluded_claims'] += 1
                for reason in check_results['exclusion_reasons']:
                    summary['exclusion_by_rule'][reason['rule_id']] += 1
            else:
                summary['included_claims'] += 1
        
        return {
            'summary': dict(summary),
            'details': results
        }
    
    def close(self):
        """Close database connections."""
        self.cursor.close()
        self.sf_conn.close()


# Example usage
if __name__ == "__main__":
    # Configuration
    snowflake_config = {
        'user': os.getenv('SNOWFLAKE_USER'),
        'password': os.getenv('SNOWFLAKE_PASSWORD'),
        'account': os.getenv('SNOWFLAKE_ACCOUNT'),
        'warehouse': os.getenv('SNOWFLAKE_WAREHOUSE'),
        'database': 'P01_EDL',
        'schema': 'EDL_RAWZ_CMPCT_ALLPHI'
    }
    
    # Initialize
    analyzer = ClaimExclusionAnalyzer(snowflake_config)
    
    # Interactive mode
    print("\n" + "=" * 80)
    print("CLAIM EXCLUSION ANALYZER (No LLM)")
    print("=" * 80 + "\n")
    
    while True:
        clcl_id = input("\nEnter Claim ID (CLCL_ID) or 'quit' to exit: ").strip()
        
        if clcl_id.lower() in ('quit', 'exit', 'q'):
            break
        
        if not clcl_id:
            continue
        
        cdml_seq_input = input("Enter Line Sequence Number (optional, press Enter to skip): ").strip()
        cdml_seq_no = int(cdml_seq_input) if cdml_seq_input else None
        
        # Analyze and display
        report = analyzer.analyze_claim(clcl_id, cdml_seq_no)
        print("\n" + report)
        
        # Ask if user wants JSON output too
        json_output = input("\nWould you like JSON output? (y/n): ").strip().lower()
        if json_output == 'y':
            json_report = analyzer.analyze_claim(clcl_id, cdml_seq_no, output_format='json')
            print("\nJSON OUTPUT:")
            print(json_report)
    
    # Close
    analyzer.close()
    print("\nAnalyzer closed. Goodbye!")
