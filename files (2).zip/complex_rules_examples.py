"""
Example Scenarios for Complex Rules
Demonstrates how each complex rule works with real-world examples
"""

from claim_analyzer_no_llm import ClaimExclusionAnalyzer
import os
from dotenv import load_dotenv

load_dotenv()

# Initialize analyzer
snowflake_config = {
    'user': os.getenv('SNOWFLAKE_USER'),
    'password': os.getenv('SNOWFLAKE_PASSWORD'),
    'account': os.getenv('SNOWFLAKE_ACCOUNT'),
    'warehouse': os.getenv('SNOWFLAKE_WAREHOUSE'),
    'database': 'P01_EDL',
    'schema': 'EDL_RAWZ_CMPCT_ALLPHI'
}

analyzer = ClaimExclusionAnalyzer(snowflake_config)

# ============================================================================
# RULE_005: TN Plan Specific Exclusion Example
# ============================================================================
print("="*80)
print("RULE_005 EXAMPLE: TN Plan Specific Exclusion")
print("="*80)
print("""
Scenario: Tennessee market claim with specific criteria

Claim Data:
  - GRGR_CK: 13 (Tennessee)
  - CSCS_ID: PL10 (in restricted plan list)
  - CLHP_FAC_TYPE: 0
  - CLHP_BILL_CLASS: 6
  - Bill Type: 066
  - CDML_FROM_DT: 2024-08-15 (AFTER 2024-06-30)

Expected Result: EXCLUDED
Reason: TN contract changes effective July 1, 2024
""")

# Example claim ID (replace with actual)
example_clcl_id = "TN_CLAIM_001"
# report = analyzer.analyze_claim(example_clcl_id)
# print(report)

# ============================================================================
# RULE_007: Expired Claims Example
# ============================================================================
print("\n" + "="*80)
print("RULE_007 EXAMPLE: Expired Claims")
print("="*80)
print("""
Scenario: NJ market claim that has expired

Claim Data:
  - GRGR_CK: 1 (New Jersey)
  - EXPIRATION_ID: 17
  - Months to Expire: -18 (18 months)
  - Expiration Type: PAID
  - Original Claim Paid Date: 2022-01-15
  - Current Date: 2024-01-29

Calculation:
  - Expiration Date = Current Date + (-18 months)
  - Expiration Date = 2024-01-29 + (-18 months) = 2022-07-29
  - Original Paid Date (2022-01-15) < Expiration Date (2022-07-29)

Expected Result: EXCLUDED
Reason: Claim expired 18 months after paid date
""")

# ============================================================================
# RULE_009: TX Provider Type Exclusion Example
# ============================================================================
print("\n" + "="*80)
print("RULE_009 EXAMPLE: TX Provider Type Exclusion")
print("="*80)
print("""
Scenario: Texas claim with specific provider specialty and revenue code

Claim Data:
  - GRGR_CK: 4 (Texas)
  - Provider Specialty (PRCF_MCTR_SPEC): S098
  - Revenue Code (RCRC_ID): 0430
  - Line 1 with RC 022 and payment > 0: NO

Expected Result: EXCLUDED
Reason: Provider specialty S098/S173 with specific revenue codes are excluded
        unless line 1 has revenue code 022 with payment

If Line 1 Had:
  - CDML_SEQ_NO: 1
  - RCRC_ID: 022
  - CDML_PR_PYMT_AMT: 100.00

Expected Result: INCLUDED (exception applies)
""")

# ============================================================================
# RULE_010: Iowa HIPAA Waiver Example
# ============================================================================
print("\n" + "="*80)
print("RULE_010 EXAMPLE: Iowa HIPAA Waiver")
print("="*80)
print("""
Scenario 1: Member with HIPAA waiver plan

Claim Data:
  - GRGR_CK: 54 (Iowa)
  - CSPI_ID: IAFPWV00 (HIPAA waiver plan)

Expected Result: EXCLUDED
Reason: Members in HIPAA FP waiver plan are protected

Scenario 2: Member found in HIPAA tables

Claim Data:
  - GRGR_CK: 54 (Iowa)
  - CSPI_ID: IAXXX (not waiver plan)
  - But member exists in FHP_PMED_MEMBER_D with PMCC communication

Expected Result: EXCLUDED
Reason: Member has HIPAA waiver in system tables
""")

# ============================================================================
# RULE_013: Missing Overpayment Pair Example
# ============================================================================
print("\n" + "="*80)
print("RULE_013 EXAMPLE: Missing Overpayment Pair")
print("="*80)
print("""
Scenario: NJ market S5102 procedure code claims

Setup:
  - Market: GRGR_CK = 1 (New Jersey)
  - Procedure: IPCD_ID like 'S5102%'
  - Member: MEME_CK = 123456
  - Service Date: 2024-01-15

Claim Group Formation:
  GROUP_ID = Hash(GRGR_CK + MEME_CK + CDML_FROM_DT)
  
Claims in Group (ordered by CLCL_RECD_DT, CLCL_ID, CDML_SEQ_NO):

Example 1: Valid Pair
  1. CLM001 (received 2024-01-20) → Reference (R)
  2. CLM002 (received 2024-02-10) → Overpayment (O)
  
  Result: Both INCLUDED (valid pair)

Example 2: Missing Overpayment
  1. CLM001 (received 2024-01-20) → Reference (R)
  2. [NO OVERPAYMENT CLAIM]
  
  Result: CLM001 EXCLUDED (no matching overpayment)
  Reason: Cannot identify recovery without overpayment pair

Example 3: Missing Reference
  1. [NO REFERENCE CLAIM]
  2. CLM002 (received 2024-02-10) → Overpayment (O)
  
  Result: CLM002 EXCLUDED (no matching reference)
  Reason: Cannot calculate recovery without reference claim

Business Logic:
  - Reference shows original payment
  - Overpayment shows what was actually owed
  - Both needed to calculate recovery amount
  - Without pair, cannot determine what to recover
""")

# ============================================================================
# RULE_014: MO Market Expiration Example
# ============================================================================
print("\n" + "="*80)
print("RULE_014 EXAMPLE: MO Market Expiration")
print("="*80)
print("""
Scenario: Missouri market claim expiration

Claim Data:
  - GRGR_CK: 234 (Missouri)
  - EXPIRATION_ID: 4354
  - Months to Expire: -24 (24 months)
  - Claim Paid Date: 2022-01-15
  - Current Date: 2024-01-29

Calculation:
  - Expiration Date = Current Date + (-24 months)
  - Expiration Date = 2024-01-29 + (-24 months) = 2022-01-29
  - Claim Paid Date (2022-01-15) < Expiration Date (2022-01-29)

Expected Result: EXCLUDED
Reason: Claim paid before expiration date, outside recovery window

Special Note for MO (CHM0021a):
  - Only applies to overpayment records (RECORD_TYPE <> 'R')
  - Different from other markets - uses paid date comparison
""")

# ============================================================================
# Combined Example: Multiple Rule Violations
# ============================================================================
print("\n" + "="*80)
print("COMBINED EXAMPLE: Multiple Rule Violations")
print("="*80)
print("""
Scenario: Claim that violates multiple rules

Claim Data:
  - GRGR_CK: 13 (Tennessee)
  - CSCS_ID: PL10
  - Bill Type: 066
  - CDML_FROM_DT: 2024-08-15
  - CLCL_TOT_PAYABLE: 8.50
  - CDML_DISALL_EXCD: A01

Rule Violations:
  1. RULE_005: TN plan with service date > 2024-06-30 ✗
  2. RULE_004: Below $10 threshold for TN market ✗
  3. RULE_002: Disallowance code A01 (ProcessedPerAppeal) ✗

Expected Result: EXCLUDED
All Three Reasons Reported:
  - TN contract changes after June 30
  - Below minimum recovery threshold
  - Unrecoverable disallowance code

Note: A claim can be excluded for multiple reasons.
      The analyzer reports ALL applicable exclusion reasons.
""")

print("\n" + "="*80)
print("END OF EXAMPLES")
print("="*80)
print("\nTo run actual analysis, uncomment the analyzer.analyze_claim() calls")
print("and replace example claim IDs with real ones from your database.")

# Clean up
analyzer.close()
