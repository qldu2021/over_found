# Claim Exclusion Analyzer (No LLM Version)

A purely programmatic analyzer that identifies why healthcare claims are excluded from the final output table. This version uses **NO LLM/AI** - all analysis is done through direct SQL queries and Python logic.

## Features

- ✅ **No External Dependencies on AI Services**: Pure programmatic analysis
- ✅ **Fast**: No API calls, instant results
- ✅ **Cost-Free**: No OpenAI costs
- ✅ **Deterministic**: Same input always produces same output
- ✅ **Detailed Reports**: Comprehensive human-readable analysis
- ✅ **JSON Export**: Machine-readable output for integration
- ✅ **Batch Processing**: Analyze multiple claims with summary statistics

## Installation

```bash
pip install snowflake-connector-python python-dotenv python-dateutil
```

Or use the requirements file:

```bash
pip install -r requirements.txt
```

## Environment Setup

Create a `.env` file with your Snowflake credentials:

```env
SNOWFLAKE_USER=your_username
SNOWFLAKE_PASSWORD=your_password
SNOWFLAKE_ACCOUNT=your_account
SNOWFLAKE_WAREHOUSE=your_warehouse
```

## Quick Start

### Interactive Mode

```bash
python claim_analyzer_no_llm.py
```

You'll be prompted to enter:
1. Claim ID (CLCL_ID)
2. Line Sequence Number (optional)
3. Whether you want JSON output

### Programmatic Usage

```python
from claim_analyzer_no_llm import ClaimExclusionAnalyzer
import os
from dotenv import load_dotenv

load_dotenv()

# Configuration
snowflake_config = {
    'user': os.getenv('SNOWFLAKE_USER'),
    'password': os.getenv('SNOWFLAKE_PASSWORD'),
    'account': os.getenv('SNOWFLAKE_ACCOUNT'),
    'warehouse': os.getenv('SNOWFLAKE_WAREHOUSE'),
    'database': 'P01_EDL',
    'schema': 'EDL_RAWZ_CMPCT_ALLPHI'
}

# Initialize analyzer
analyzer = ClaimExclusionAnalyzer(snowflake_config)

# Analyze a single claim
report = analyzer.analyze_claim('CLM123456789')
print(report)

# Get JSON output instead
json_output = analyzer.analyze_claim('CLM123456789', output_format='json')
print(json_output)

# Analyze multiple claims
results = analyzer.analyze_multiple_claims(['CLM001', 'CLM002', 'CLM003'])
print(f"Excluded: {results['summary']['excluded_claims']}")
print(f"Included: {results['summary']['included_claims']}")

# Clean up
analyzer.close()
```

## Rules Checked

The analyzer checks the following exclusion rules:

### Simple Rules

| Rule ID | Name | Description |
|---------|------|-------------|
| RULE_001 | Excluded Markets | Markets 10, 12, 15, 20, 22 (NM, MD-VANT, VA, VA-VANT) |
| RULE_002 | Unrecoverable Disallowance Codes | FA5, FA7, A01-A58, K01-K25 (Appeal and plan approval codes) |
| RULE_003 | HMS/Connolly Line Items | EOB codes FA6 (HMS), FA8 (Connolly) |
| RULE_004 | Below Payment Threshold | <$25 (or <$10 for FL, KY, TN, VA-MM markets) |
| RULE_011 | Capitated Member Exclusion | MEME_MEDCD_NO = AGPCLMRCOUP |
| RULE_012 | Hospital Claims Filter | Claim ID starts with 'H' |

### Complex Rules

#### RULE_005: TN Plan Specific Exclusion (CHM0021b)
**Description**: Tennessee market specific exclusion for certain plans and bill types after June 30, 2024

**Criteria** (ALL must be met):
- GRGR_CK = 13 (Tennessee market)
- Plan IDs: PL10, PL11, PL12, PL95, PL96, PL97, CD04, CD05, CD06, CD07, CD08, CD09
- Bill Types: 066 or 089 (Facility Type + Bill Class)
- Service Date (CDML_FROM_DT) > 2024-06-30

**Business Impact**: TN contract changes effective July 1, 2024 exclude these claims from recovery

**Example Exclusion**:
```
Market: Tennessee (13)
Plan: PL10
Bill Type: 066
Service Date: 2024-08-15
Reason: Date after 2024-06-30 cutoff
```

#### RULE_006: Malicious Override Codes
**Description**: Claims with manual override codes in various tables

**Override Codes**: J00, J01, J02, JCN, YHK, EAM, G03, G97, FD3, FD4, FD5

**Tables Checked**:
- CDML (Claim Line)
- CDOR (Line Override)
- CLOR (Claim Override)
- ADJ_CLM_RSN (Adjustment Reason)

**Business Impact**: Claims with manual overrides cannot be automatically recovered

#### RULE_007: Expired Claims (Complex)
**Description**: Claims that have exceeded their expiration date based on market-specific rules

**Expiration Types**:
- **PAID**: Based on paid date
- **DOS**: Based on date of service
- **RECD**: Based on received date

**Market-Specific Logic**:

| Market | GRGR_CK | Expiration Logic |
|--------|---------|------------------|
| NJ | 1 | Special handling: checks original claim paid date |
| FL | 3 | Different rules for facility vs. non-facility claims |
| VA MED-SUPP | 67 | Different rules for facility vs. non-facility claims |
| MO | 234 | Paid date based expiration |
| All Others | Various | Market-specific expiration IDs and months |

**Example**: 
- Market: NJ (GRGR_CK = 1)
- Expiration Rule: 18 months from paid date
- Original Claim Paid: 2022-01-15
- Expiration Date: 2023-07-15
- Current Date: 2024-01-29
- Result: EXCLUDED (expired)

**Special Cases**:
1. **FL Market (GRGR_CK = 3)**:
   - Non-facility (no CLHP_FAC_TYPE): Uses EXPIRATION_ID 6
   - Facility claims: Uses EXPIRATION_ID 28
   - T2030 procedure codes treated as facility

2. **VA MED-SUPP (GRGR_CK = 67)**:
   - Non-facility: Uses EXPIRATION_ID 3907
   - Facility: Uses EXPIRATION_ID 3908

#### RULE_008: DC Market Date Filter
**Description**: DC market claims with service dates before 2017-01-01

**Criteria**:
- GRGR_CK = 6 (DC market)
- CDML_FROM_DT < 2017-01-01

**Business Impact**: Historical claims outside recovery window

#### RULE_009: Provider Type Exclusion (TX Markets)
**Description**: Texas market claims with specific provider specialties and revenue codes

**Criteria** (ALL must be met):
- GRGR_CK in (4, 23, 27, 88, 52) - TX markets
- Provider Specialty: S098 or S173
- Revenue Code in: 0100, 0101, 0230, 0410, 0430, 0431, 0433
- NO line sequence 1 with revenue code 022 and payment > 0

**Business Impact**: Specific provider arrangements preclude recovery

**Example**:
```
Market: TX (GRGR_CK = 4)
Provider Specialty: S098
Revenue Code: 0430
Line 1 RC 022: Not present
Result: EXCLUDED
```

#### RULE_010: HIPAA Waiver IA (Iowa)
**Description**: Iowa market HIPAA FP waiver exclusions

**Criteria** (Either):
1. Plan ID (CSPI_ID) = 'IAFPWV00', OR
2. Member found in FHP_PMED_MEMBER_D and FHP_PMCC_COMM_X tables

**Tables Checked**:
- CMC_SBSB_SUBSC_CMPCT_ACTV (Subscriber)
- CMC_GRGR_GROUP_CMPCT_ACTV (Group)
- FHP_PMED_MEMBER_D_CMPCT_ACTV (Member)
- FHP_PMCC_COMM_X_CMPCT_ACTV (Communication)

**Business Impact**: Members with HIPAA waivers protected from recovery

#### RULE_013: Missing Overpayment Pair (Very Complex)
**Description**: Reference or overpayment records without matching counterpart

**Logic**:
1. Claims are grouped by: GRGR_CK + MEME_CK + CDML_FROM_DT
2. Within each group, claims are ordered by: CLCL_RECD_DT + CLCL_ID + CDML_SEQ_NO
3. First claim in group = Reference (R)
4. Subsequent claims = Overpayment (O)
5. Both R and O must exist for pair to be valid

**Exclusion Conditions**:
- Reference record exists BUT no overpayment → EXCLUDE reference
- Overpayment exists BUT no reference → EXCLUDE overpayment

**Requirements**:
- GRGR_CK = 1 (NJ market - this logic is NJ-specific)
- CLCL_CUR_STS = '02'
- IPCD_ID LIKE 'S5102%' (procedure code)
- CDML_PR_PYMT_AMT > 0

**Business Impact**: Cannot identify recovery without paired transactions

**Example**:
```
Group ID: 12345
Member: MEME_CK 999999
Service Date: 2024-01-15

Claims in Group:
1. CLM001 (received 2024-01-20) → Reference (R)
2. CLM002 (received 2024-02-10) → Overpayment (O)

Result: Both kept (valid pair)

If CLM002 missing:
Result: CLM001 EXCLUDED (no overpayment pair)
```

#### RULE_014: MO Market Expiration
**Description**: Missouri market-specific expiration rules

**Criteria**:
- GRGR_CK = 234 (Missouri market)
- Uses EXPIRATION_ID = 4354
- Checks if claim has expired based on paid date

**Calculation**:
1. Get months_to_expire from expiration rule
2. Calculate expiration date: CURRENT_DATE + months_to_expire
3. If expiration date >= claim paid date → EXCLUDED

**Business Impact**: Market-specific expiration rules for MO

## Example Output

```
================================================================================
CLAIM EXCLUSION ANALYSIS REPORT
================================================================================

CLAIM INFORMATION:
  Claim ID: CLM123456789
  Line Items Checked: 1

KEY CLAIM DATA:
  Market (GRGR_CK): 13
  Plan ID (CSCS_ID): PL10
  Total Payable: $150.00
  Service Date: 2024-08-15
  Paid Date: 2024-08-20
  Bill Type: 066

================================================================================
VERDICT: EXCLUDED
================================================================================

EXCLUSION REASONS:

1. [RULE_005] TN Plan Specific Exclusion
   Message: EXCLUDED: TN market (PL10), bill type 066, date 2024-08-15 > 2024-06-30
   SQL Reference: CHM0021b
   Business Impact: TN contract changes effective July 1, 2024
   Details:
     - grgr_ck: 13
     - market: Tennessee
     - cscs_id: PL10
     - bill_type: 066
     - service_date: 2024-08-15
     - cutoff_date: 2024-06-30
   Explanation: TN contract changes effective July 1, 2024 exclude these claims from recovery

RULES PASSED: 8

  ✓ [RULE_001] Excluded Markets
    Passed: Not in excluded markets
  ✓ [RULE_002] Unrecoverable Disallowance Codes
    Passed: No excluded disallowance codes found
  ✓ [RULE_003] HMS/Connolly Line Items
    Passed: No HMS/Connolly exclusion codes
  ✓ [RULE_004] Below Payment Threshold
    Passed: Total payable $150.00 meets threshold
  ✓ [RULE_006] Malicious Override Codes
    Passed: No excluded override codes found
  ✓ [RULE_008] DC Market Date Filter
    Passed: Not DC market or date within range
  ✓ [RULE_011] Capitated Member Exclusion
    Passed: Not a capitated member
  ✓ [RULE_012] Hospital Claims Filter
    Passed: Not a hospital claim

================================================================================
END OF REPORT
================================================================================
```

## JSON Output Format

```json
{
  "claim_id": "CLM123456789",
  "cdml_seq_no": null,
  "verdict": "EXCLUDED",
  "line_items_checked": 1,
  "exclusion_reasons": [
    {
      "rule_id": "RULE_005",
      "rule_name": "TN Plan Specific Exclusion",
      "message": "EXCLUDED: TN market (PL10), bill type 066, date 2024-08-15 > 2024-06-30",
      "details": {
        "grgr_ck": 13,
        "market": "Tennessee",
        "cscs_id": "PL10",
        "bill_type": "066",
        "service_date": "2024-08-15",
        "cutoff_date": "2024-06-30",
        "reason": "TN contract changes effective July 1, 2024 exclude these claims from recovery"
      },
      "sql_reference": "CHM0021b",
      "business_impact": "TN contract changes effective July 1, 2024"
    }
  ],
  "passed_rules": [
    {
      "rule_id": "RULE_001",
      "rule_name": "Excluded Markets",
      "message": "Passed: Not in excluded markets"
    }
  ],
  "claim_data": {
    "CLCL_ID": "CLM123456789",
    "GRGR_CK": 13,
    "CSCS_ID": "PL10",
    "CLCL_TOT_PAYABLE": 150.00,
    "CDML_FROM_DT": "2024-08-15",
    "CLHP_FAC_TYPE": "0",
    "CLHP_BILL_CLASS": "6"
  }
}
```

## Batch Processing

```python
# Analyze multiple claims
claim_list = ['CLM001', 'CLM002', 'CLM003', 'CLM004', 'CLM005']
results = analyzer.analyze_multiple_claims(claim_list)

# Print summary
print(f"Total Claims: {results['summary']['total_claims']}")
print(f"Excluded: {results['summary']['excluded_claims']}")
print(f"Included: {results['summary']['included_claims']}")
print(f"Errors: {results['summary']['errors']}")

# Print exclusion breakdown
print("\nExclusions by Rule:")
for rule_id, count in results['summary']['exclusion_by_rule'].items():
    print(f"  {rule_id}: {count} claims")

# Access individual results
for clcl_id, result in results['details'].items():
    if result['verdict'] == 'EXCLUDED':
        print(f"\n{clcl_id}: {len(result['exclusion_reasons'])} reasons")
```

## Export to File

```python
import json

# Analyze claim
check_results = analyzer.run_all_checks('CLM123456789')

# Save as JSON
with open('claim_analysis.json', 'w') as f:
    json.dump(check_results, f, indent=2, default=str)

# Save formatted report
report = analyzer.analyze_claim('CLM123456789')
with open('claim_report.txt', 'w') as f:
    f.write(report)
```

## Adding Custom Rules

Extend the analyzer by adding your own rules:

```python
def evaluate_rule_015(self, claim_data: Dict) -> Tuple[bool, str, Dict]:
    """Check for your custom exclusion logic."""
    
    # Your logic here
    if some_condition:
        details = {
            'field1': value1,
            'field2': value2,
            'reason': 'Explanation of why excluded'
        }
        return True, "Brief message", details
    
    return False, "Passed: Your rule description", {}

# Add to EXCLUSION_RULES dictionary
EXCLUSION_RULES['RULE_015'] = {
    'name': 'Your Rule Name',
    'description': 'What this rule checks',
    'sql_ref': 'Reference to SQL code',
    'business_impact': 'Why this matters',
    'check_type': 'complex'
}

# Add to rules_to_check list in run_all_checks()
rules_to_check.append(('RULE_015', lambda: self.evaluate_rule_015(claim_data)))
```

## Performance

- **Single Claim Analysis**: 0.5-2 seconds (depending on rule complexity)
- **Batch Processing**: ~1-2 seconds per claim
- **No API Costs**: Zero external API calls
- **Database Impact**: Minimal (uses indexes, efficient queries)

## Advantages Over LLM Version

| Feature | No LLM | With LLM |
|---------|--------|----------|
| Speed | ⚡ Instant | 🐢 3-5 seconds |
| Cost | 💰 Free | 💸 $0.01-0.03/claim |
| Consistency | ✅ Always same | ❓ May vary |
| Explanation Quality | ✅ Structured | ✅✅ Natural language |
| Offline Capability | ✅ Yes | ❌ No |
| Dependencies | ✅ Only Snowflake | ❌ OpenAI required |

## Troubleshooting

### "Claim not found"
- Verify claim ID exists
- Check database/schema configuration
- Ensure warehouse is active

### "Error checking rule"
- Check database permissions
- Verify all required tables exist
- Review error message in passed_rules section

### Slow Performance
- Check Snowflake warehouse size
- Verify network connectivity
- Consider increasing warehouse for batch jobs

## Integration Examples

### REST API Wrapper

```python
from flask import Flask, jsonify, request

app = Flask(__name__)
analyzer = ClaimExclusionAnalyzer(snowflake_config)

@app.route('/analyze/<clcl_id>')
def analyze(clcl_id):
    result = analyzer.run_all_checks(clcl_id)
    return jsonify(result)

if __name__ == '__main__':
    app.run(port=5000)
```

### Scheduled Batch Job

```python
import schedule
import time

def daily_analysis():
    # Get claims from yesterday
    claims = get_yesterday_claims()
    results = analyzer.analyze_multiple_claims(claims)
    
    # Send report
    send_email_report(results)

schedule.every().day.at("07:00").do(daily_analysis)

while True:
    schedule.run_pending()
    time.sleep(60)
```

## License

Internal use only - Proprietary

## Support

For questions or issues, contact the Data Analytics team.
